/*
 TODO we should add to each onload for images an onerror to trace issues with image loading
 */

var rb = {};
var stockArt = false;
var BRIGHTNESS_DEFAULT = 0;
var CONTRAST_DEFAULT = 0;
var SCALE_DEFAULT = 1;
var ROTATE_DEFAULT = 1800;
var ROTATE_MODIFIER = 10;
var ROTATE_DIFF = 180;
var SCALE_MODIFIER = 100;
var MIN_SCALE  = 10;
var MAX_SCALE = 190;
var MIN_ANGLE = 0;
var MAX_ANGLE = 3600;
var REEL_GENERATION_STATUS_UPDATE = 5300;

var CANVAS_PAD_CONST = 10;
var CANVAS_PAD_CORNER = 10;

var  BROWSER_SHORT_HEIGHT_LARGE = 800;
var  BROWSER_SHORT_HEIGHT_MEDIUM = 600;
var  BROWSER_SHORT_HEIGHT_SMALL = 400;
var  BROWSER_SHORT_HEIGHT_LARGE_ZOOMZOOM = .5; // 0.5
var  BROWSER_SHORT_HEIGHT_MEDIUM_ZOOMZOOM = .5; //0.3;
var  BROWSER_SHORT_HEIGHT_SMALL_ZOOMZOOM = .5; //0.2;

var DEFAULT_FONT = 'arial';

// NOTE phantom does math differently....
var FABRIC_SHADOW_SMALL = '1px 1px 2px';
var FABRIC_SHADOW_LARGE = '2px 2px 4px';
var FABRIC_SHADOW_DARK = 'rgba(45,45,45,0.5)';
var FABRIC_SHADOW_LIGHT = 'rgba(200,200,200,0.5)';


// finally down 1st position is X - test 2
var PHANTOM_FABRIC_SHADOW_SMALL = '0px 5px 1px';
var PHANTOM_FABRIC_SHADOW_LARGE = '0px 5px 2px';
var PHANTOM_FABRIC_SHADOW_DARK = 'rgba(45,45,45,0.25)';
var PHANTOM_FABRIC_SHADOW_LIGHT = 'rgba(200,200,200,0.5)';


var SMALL_IMAGE_WIDTH_PIXELS = 400;
var MESSAGE_TIMEOUT_SMALL_IMAGE = 5100;
var BLOCKED_VIA_IMAGE_SIZE = 3;
var FRAME_COUNT = 8;
var CENTER_ART_DELAY_TIME = 500;
var CHANGE_FRAME_DELAY_TIME = 1300;

/* Film Strip Overlay */
var maskOverlay = jQuery('<div class="ui-widget-overlay ui-front"></div>');
var centerOverlay = jQuery('<div class="ui-widget-overlay ui-front2"></div>');
function addMaskOverlay($param) {
	$param.closest('.ui-dialog').after(maskOverlay);
}
function removeMaskOverlay() {
	jQuery('.ui-widget-overlay').remove();
}

/* Creation Guideline */
var ReelBuilder = Class.create({

	initialize:function() {
		this.postUrl = RB_AJAX_URL;
		// stateful divis visble on fully loaded ....
		// TODO not really used yet.
		this.mode = "desktop";
		this.debugMode = false;

		this._recent_json = false;
		this._completedPhantomJs = false;
		this._save_image_recent_json = false;
		this.skipTextUpdate = false;
		this.frameData = new Array();
		// NOTE this refers to the frame_data[x].frame_index it DOES not represent the positio in the frameDAta
		this.currentFrameIndex = 1;
		this.currentFrameImage = false;
		this.beforeCenterFrameEntityId = false;
		this.reel_id = -1;
		this.consoleHistory = '';
		this.skipCanvasUpdate = false;

		this.saveAndExitBit = false;
		this.reelSaveWasSuccess = false;
		this.saveCenterAndChangeFrame = false;
		this.saveandChangeFrameBit = false;
		this.saveandOpenCenter = false;
		this.saveandContinuePreview = false;
		this.frameCanvas = false;
		this.filtersProcessing = false;
		this.previewPosition = false;
		this.previewGenerationUpdater = false;
		this.previewTime = false;
		this.reorderIsBlocked = false;
		this.canvas = false;
		this.centerCanvas = false;
		this.renderedCanvasCalled = false;
		this.renderedCanvasDelay = 600;
		this.state = false;
		this.imageFrame = false;
		this.textFrame = false;
		this.frameHasChanges = false;
		this.textDragBox = false;
		this.canvasHash = false;
		this.unsavedReorder = false;
	},



	setupCssZoomForSmallScreens: function() {
		//Small screen sizes
		// just do it on loadd, then they can change the size
		// was breaking tablet layout
//	jQuery(window).on("load resize scroll",function(e){
		return;
		jQuery(window).on("load",function(e){
			if(jQuery(window).height() < BROWSER_SHORT_HEIGHT_LARGE) {
				jQuery(".page").css({"zoom":BROWSER_SHORT_HEIGHT_LARGE_ZOOMZOOM});
			} else if(jQuery(window).height() < BROWSER_SHORT_HEIGHT_MEDIUM) {
				jQuery(".page").css({"zoom":BROWSER_SHORT_HEIGHT_MEDIUM_ZOOMZOOM});
			} else if(jQuery(window).height() < BROWSER_SHORT_HEIGHT_SMALL) {
				jQuery(".page").css({"zoom":BROWSER_SHORT_HEIGHT_SMALL_ZOOMZOOM});
			}
		});

	},

	enableFrameHover: function(relation) {
		jQuery(".frames").removeClass("frame-hover");
		//jQuery('li[rel="' + relation + '"]').addClass('frame-hover');
		jQuery('li[data-frame-id="' + relation + '"]').addClass('frame-hover');
	},

	setupFrameDragOrDeviceClick: function() {

		var muck = false;
		jQuery(document).bind("click tap", function(e) {
			muck = e.target;
//			rb.log(" click we need to find item " + jQuery(e.target).html());
		});


		//if(rb.isTouchDevice()) {
		// has to be on the document so they can click off of it
		jQuery('#reorder-tablettabs').show();
		jQuery(".frames").bind("click tap", function() {
			rb.log(" click for frame hover");
			jQuery(".frames").removeClass("frame-hover");
			jQuery(this).addClass('frame-hover');
		});

		//jQuery(document).click(function(e) {
		//	if(!jQuery(e.target).closest('li').hasClass('frames')) {
		//		rb.log(" click - remove hover");
		//
		//		jQuery(".frames").removeClass("frame-hover");
		//	}
		//});
		/*
		 } else {
		 //Add hover frame class
		 jQuery('#reorder-tablettabs').hide();
		 jQuery(".frames").hover(function(){
		 jQuery(this).addClass('frame-hover');
		 }, function(){
		 jQuery(this).removeClass('frame-hover');
		 });

		 }
		 */



	},

	isTouchDevice: function () {

		return 'ontouchstart' in window // works on most browsers
			|| 'onmsgesturechange' in window // works on ie10
			|| 'ontouchstart' in document.documentElement || navigator.userAgent.indexOf('Android') != -1;

		try {
			document.createEvent("TouchEvent");
			return true;
		} catch (e) {
			return false;
		}
		return false;
	},

	needsBrowserUpgrade: function() {
		var ieBrowser = undefined;
		try {
			var ieBrowser = (function(){

				var undef,
					v = 3,
					div = document.createElement('div'),
					all = div.getElementsByTagName('i');

				while (
					div.innerHTML = '<!--[if gt IE ' + (++v) + ']><i></i><![endif]-->',
						all[0]
					);

				return v > 4 ? v : undef;

			}());

		} catch (Err) {
			return false;
		}
		return ieBrowser !== undefined && ieBrowser < 9;
	},

	centerActiveImage: function() {
		try {
			rb.currentFrameImage.left = rb.getCanvas().getWidth()/2;
			rb.currentFrameImage.top = rb.getCanvas().getHeight()/2;
			rb.renderCanvas();
		} catch (err) {

		}

	},
	
	sendGaEvent: function(action, label, value) {

		if(rb.getUrlParameter('process_frame_image')) {
			// the phontom needs no GA
			return;
		}

		try {
			var category = 'celebrate_reelbuilder';
		 _gaq.push(['_trackEvent', category, action, label, value, '1']);
}	catch(Err) {
			//rb.log("error in calling GA event");
			//rb.log(Err);
		}
	},

	dclog: function()
	{
		jQuery('<div style=" height: 300px;     overflow: auto;  width: 300px; "><pre>' + rb.consoleHistory + '</pre></div>').dialog().css('height: 300px;     overflow: auto;  width: 300px;');
	},

	debugModeEnabled: function() {

		console.log("DEBUG MODE REEL BUILDER");
		rb.debugMode = true;
		// will enable "lite" FB option
		if(0) {
			(function(F,i,r,e,b,u,g,L,I,T,E){if(F.getElementById(b))return;E=F[i+'NS']&&F.documentElement.namespaceURI;E=E?F[i+'NS'](E,'script'):F[i]('script');E[r]('id',b);E[r]('src',I+g+T);E[r](b,u);(F[e]('head')[0]||F[e]('body')[0]).appendChild(E);E=new Image;E[r]('src',I+L);})(document,'createElement','setAttribute','getElementsByTagName','FirebugLite','4','firebug-lite.js','releases/lite/latest/skin/xp/sprite.png','https://getfirebug.com/','#startOpened');

		}

	},

	log : function(x, isException) {

		isException = typeof isException != undefined && isException ? isException : false;
		if(!isException && !rb.debugMode) {
			return ;
		}

		var d = new Date();
		var isoDate = d.toISOString();

		rb.consoleHistory += "\n" + isoDate + ' - ' + x;
		console.log(x);

		if(typeof isException != undefined && isException) {

			try {
				var xData = {
					_js_exception: 1,
					customer_id: CUSTOMER_ID,
					customer_loggedin: CUSTOMER_ID,
					url: document.location.href
				};


				try {
					xData['exceptionString']  = String(x);
				} catch (Err) {
					// move along
				}

				try {
					xData['exception']  = JSON.stringify(x);
				} catch (Err) {
					// move along
				}

				try {
					xData['exceptionStackTrace']  = JSON.stringify(x.stack);
				} catch (Err) {
					// move along
				}

				try {
					// TODO update with live canvas - replace base64 with urls
					//	xData['rb_object']  = JSON.stringify(rb);
					//	xData['rb_object']  = "need to strip images out of canvas before we send it";
					xData['recent_json']  = rb.recent_json;
				} catch (Err) {
					// move along
				}


				jQuery.ajax({
					type: "POST",
					url: rb.postUrl,
					data: xData,
					dataType: 'json'
				});
			} catch (Err) {
				// we tried to post the error for logging. nothing to see here
				console.log("FAILED posting exception");
			}

		}

	},

	helpOverlay: function() {
		rb.sendGaEvent('help_overay', "launch", 0);

		jQuery('#rb-help-overlay').dialog({
			width: '700', 
			height: 'auto',
			resizable: false, 
			modal: true, 
			dialogClass: 'rb-help-overlay',
			left: '50%', 
			top: '18%', 'margin-left': '-350px', 
			open: function(event, ui) { jQuery(".ui-dialog-titlebar").hide(); },
			close : function(){
				jQuery("#rb-help-overlay .step").removeClass("current").hide();
				jQuery("#rb-help-overlay #step1").addClass("current").css("display","block");
			}, buttons: [
			{
				text: "Previous",
				id: "prev",
				attr: "disabled",
				icons: {
					primary: "ui-icon-carat-1-w"
				},
				click: function() {
					jQuery('#rb-help-overlay .current').removeClass('current').hide()
						.prev().show().addClass('current');
					if (jQuery('.current').hasClass('first')) {
						jQuery('#prev').attr('disabled', true);
						jQuery("#prev").hide();
					}
					jQuery('#next').attr('disabled', null);
					jQuery("#next").show();
				}
			},
			{ text: "Next",
				id: "next",
				icons: {
					primary: "ui-icon-carat-1-e"
				},
				click: function() {
					jQuery("#prev").show();
					jQuery('#rb-help-overlay .current').removeClass('current').hide()
						.next().show().addClass('current');
					if (jQuery('.current').hasClass('last')) {
						jQuery("#next").hide();
						jQuery('#next').attr('disabled', true);
					}
					jQuery('#prev').attr('disabled', null);
				}
			},
			{ text: "Cancel",
				id: "Cancel",
				click: function() {
					jQuery(this).dialog("close");
				}
			}]
		});
		jQuery("#prev").hide();
	},

	howtoOverlay: function() {
		jQuery('#rb-howto-overlay').clone().dialog({
			width: '850', 
			height: 'auto', 
			resizable: false, 
			modal: true, 
			dialogClass: 'rb-howto-overlay', 
			open: function(event, ui) { jQuery(".ui-dialog-titlebar").hide(); },
			buttons : {
				"Cancel" : function() {
					var clone = jQuery("#howto").clone(true);
					jQuery(".howto-flash-container #howto").attr('id','howtoRemove');
					jQuery(".howto-flash-container #howtoRemove").remove();
					clone.appendTo('.howto-flash-container');
					jQuery(this).dialog("close");
				}
			},
			left: '50%', 
			top: '18%', 
			'margin-left': '-350px' 
		});
	},


	showLoading: function(showPercentage) {
		if(typeof showPercentage == "undefined") {
			showPercentage = false;
		}

		jQuery('#rb-loading').show();
		jQuery('#rb-loading').children().show();
		jQuery('.complete-percentage').hide();
		rb.updateLoadingMessage('');


		if(showPercentage) {
			jQuery('.complete-percentage').show();
			//Percentage Load
			var percentage = jQuery('#percentage');
			width = 0;
			var interval = setInterval(function() {
				width += 5;
				percentage.text(width + '%');
				if(jQuery('#rb-loading').css('display') == 'none') {
					clearInterval(interval);
					width = 0;
					percentage.text(width + '%');
				} else {
					if (width >= 100) {
						percentage.text('100%');
						clearInterval(interval);
					}
				}
			}, 4000);
		}
	},

	hideLoading: function(data) {
		// TODO implement loading % on upload and generate reel?
		// see function showAjaxLoadingProgress
		jQuery('#rb-loading').hide();
		var percentage = jQuery('#percentage');
		rb.updateLoadingMessage('');

		percentage.text('0%');
	},


	loadStockArt: function(path) {
		rb.showLoading();
		rb.log("stock art assign");
		rb.log(path);
		if(!path) {
			rb.hideLoading();
			rb.log("failed to load stock art path " + path , true );
			document.reload();
			return;
		}
		stockArt.removeDialog();

		var loadingImg = new Image();

		loadingImg.onload = function () {

			rb.log("loading STOCK image");
			// set it in the object
			rb.frameData[rb.getCurrentFrameDataPosition()].source_file = path;
			rb.setNewImage(loadingImg, true);
			rb.hideLoading();
		}

		loadingImg.src = path;
	},

	updateResizeMessage: function(imgObj) {

		var canvasWidth = rb.currentFrameIndex == 0 ? CENTER_WIDTH : FRAME_WIDTH;
		var canvasHeight = rb.currentFrameIndex == 0 ? CENTER_HEIGHT : FRAME_HEIGHT;
		var needsResize = (imgObj.width > canvasWidth*MAX_UPLOAD_MUX || imgObj.height > canvasHeight*MAX_UPLOAD_MUX);
		if(needsResize) {
			rb.disableReorder(MSG_IMAGE_BEEN_RESIZED, 4500);
			return true;
		}
		return false;
	},

	addImageToCanvas: function(image) {
		if(rb.currentFrameImage) {
			rb.getCanvas().remove(rb.currentFrameImage);
		}
		rb.resetImageTools();

		rb.currentFrameImage = rb.loadFabricImageFrame(image);

		rb.getCanvas().add(rb.currentFrameImage);

		rb.bringTextToFront();
		rb.setActiveThumbObjectBackground();
	},

	setNewImage: function(image, forceUpdate, resizedTmpImage) {


		if(typeof forceUpdate == "undefined" || forceUpdate == undefined) {
			forceUpdate = false;
		}

		if(typeof resizedTmpImage == "undefined" || resizedTmpImage == undefined) {
			resizedTmpImage = image;
		}

		rb.addImageToCanvas(resizedTmpImage);


		if(rb.currentFrameImage.width <= SMALL_IMAGE_WIDTH_PIXELS) {
			rb.log(" checking for small image " + resizedTmpImage.width );
			rb.blockReorder();
			rb.reorderIsBlocked = BLOCKED_VIA_IMAGE_SIZE;
			jQuery('.reorder-strip-container .ui-widget-overlay, .frame-list-notice').remove();
			jQuery('.centerlabel-container .ui-widget-overlay').remove();
			rb.disableReorder(MSG_LOW_RES_IMAGE, MESSAGE_TIMEOUT_SMALL_IMAGE);

		}



		if(forceUpdate || resizedTmpImage.src.indexOf('http://') == -1) {
			var rbReturn = rb.saveNewImage(resizedTmpImage.src);
			rb.updateCanvasOverlay();
			rb.log("we sent the image up");
		}


	},

	setCurrentImageDefaultScale: function() {
		var imgObj = rb.currentFrameImage;

		var initialScale = rb.getImageScaleValue(img);

		rb.currentFrameImage.scaleX = initialScale;
		rb.currentFrameImage.scaleY = initialScale;

		rb.renderCanvas();
		rb.bringTextToFront();

		jQuery('#slider-scale').slider('option', 'value', initialScale*SCALE_MODIFIER);
	},

	resizeImageBeforeUpload:  function(imgObj) {

		rb.log("resizing.. ");
		try {

			var resizeCanvas =  document.createElement("canvas");
			// set to frame dims OR CENTER
			var maxWidth = FRAME_WIDTH*MAX_UPLOAD_MUX;
			var maxHeight = FRAME_HEIGHT*MAX_UPLOAD_MUX;
			resizeCanvas.width = maxWidth;
			resizeCanvas.height = maxHeight;

			if(rb.currentFrameIndex == 0) {
				//Preserve the aspect ratio
				var aspect = imgObj.width / imgObj.height;
				if (aspect < 1) {
					resizeCanvas.width = CENTER_WIDTH*MAX_UPLOAD_MUX*aspect;
					resizeCanvas.height = CENTER_HEIGHT*MAX_UPLOAD_MUX;
				} else if (aspect > 1) {
					resizeCanvas.width = CENTER_WIDTH*MAX_UPLOAD_MUX;
					resizeCanvas.height = CENTER_HEIGHT*MAX_UPLOAD_MUX*(1/aspect);
				} else {
					resizeCanvas.width = CENTER_WIDTH*MAX_UPLOAD_MUX;
					resizeCanvas.height = CENTER_HEIGHT*MAX_UPLOAD_MUX;
				}
			} else {

				if(imgObj.width >= imgObj.height) {
					resizeCanvas.height = imgObj.height * (maxWidth/imgObj.width);
				} else {
					resizeCanvas.width = imgObj.width * (maxHeight/imgObj.height)
				}
			}

			var resizeCtx = resizeCanvas.getContext('2d');
			var resizeImageData = false;

			resizeCtx.drawImage(imgObj, 0, 0, imgObj.width, imgObj.height,
				0, 0, resizeCanvas.width, resizeCanvas.height);
			// TODO might be smaller
			//resizeImageData = resizeCanvas.toDataURL({format:jpeg, quality:1});
			resizeImageData = resizeCanvas.toDataURL();
			rb.log(" got image data baxk.. ");
			resizeCanvas = false;
			resizeCtx = false;
			if(!resizeImageData) {
				rb.log(" FAILED  resize continue with original.. ");
				rb.sendGaEvent('resize_image_failed', "upload_image", 0);
				rb.continueUploaderChange(imgObj);
			} else {
				var resizedImg = new Image();
				resizedImg.onload = function() {
					rb.log("continue after resize.. ");
					rb.sendGaEvent('resize_image_success', "upload_image", 0);
					rb.continueUploaderChange(imgObj, resizedImg);
				};
				resizedImg.src = resizeImageData;
			}
			// send the resizeCanvas image along with the original to the next step
		} catch (Err) {
			rb.log(" issue with resizing image");
			rb.log(Err, true);
			rb.continueUploaderChange(imgObj, imgObj);
		}

		//return imageData;
	},

	continueUploaderChange: function(imgObj, resizedTmpImage) {
		jQuery("#imgLoader").val("");
		rb.setNewImage(imgObj, false, resizedTmpImage);
		rb.hideLoading();
	},

	uploaderChange: function(target) {
		rb.log("we have an image change");
		// NOTE: IE 9 does not support this.
		// we have to either use flash or disable ie 9 (* done)

		try {
		if(target.files[0].name.toLowerCase().indexOf('png') == -1 &&
			target.files[0].name.toLowerCase().indexOf('jpg') == -1 &&
			target.files[0].name.toLowerCase().indexOf('jpeg') == -1) {
			rb.hideLoading();
			jQuery("#imgLoader").val("");
			jQuery('.ui-dialog-content').dialog('close');
			jQuery('<div />').html(MSG_LIMITED_UPLOAD_FILES).dialog({
				autoOpen: true,
				modal: true,
				height: 'auto',
				resizable: false,
				buttons : {
					"OK" : function() {
						jQuery(this).dialog("close");

					}
				}
			});
			jQuery(".ui-dialog-titlebar").hide();

			return false;
		}
		} catch (Err) {
// IE throw a fit
}
		var reader = new FileReader();
		rb.showLoading();
		jQuery('.ui-dialog-content').dialog('close');

		reader.onload = function (event) {
			var imgObj = new Image();

			imgObj.onload = function () {
				rb.log("loaded img - testing resize ");
				var needsResize = rb.updateResizeMessage(imgObj);
				// resizing client side didnt seem to save transfer amounts
				if(needsResize) {

					rb.log("loaded img - forcing resize");
					rb.resizeImageBeforeUpload(imgObj)
				} else {
					rb.log("loaded img - no resize");
					rb.continueUploaderChange(imgObj, imgObj);
				}
			};
			imgObj.src = event.target.result;
		};

		try {
			reader.readAsDataURL(target.files[0]);
		} catch(Err) {
			// TODO : IE exception thrown. doesnt break the page - we ignore it.
			rb.log("exception in IE uploadd change.. ");
			if(Err.message != 'TypeMismatchError') {
				rb.log("exception in uploade change");
				rb.log(Err, true);
			}
		}
	},

	updateUrlReelId: function() {
		// rb._recent_json.data.entity_id
		if(!rb.getUrlParameter('reel_id') && typeof rb._recent_json == 'object' && rb._recent_json.data.entity_id) {
			try {
				rb.reel_id = rb._recent_json.data.entity_id;
				history.pushState({},"Reelbuilder - Reel Id:" + String(rb._recent_json.data.entity_id),  BASE_URL + "reelbuilder?reel_id=" + String(rb._recent_json.data.entity_id));
			} catch (err) {
				// not important..
			}
		}
	},

	getUrlParameter: function (sParam)
	{
		var sPageURL = window.location.search.substring(1);
		var sURLVariables = sPageURL.split('&');
		for (var i = 0; i < sURLVariables.length; i++)
		{
			var sParameterName = sURLVariables[i].split('=');
			if (sParameterName[0] == sParam)
			{
				return sParameterName[1];
			}
		}
		return false;
	},

	notifyBrowserUpgrade: function()  {
		jQuery('<div />').html(MSG_BROWSER_UPGRADE).dialog({
			autoOpen: true,
			modal: true,
			height: 'auto',
			resizable: false,
			buttons : {
				"OK" : function() {
					jQuery(this).dialog("close");
					document.location.href = BASE_URL + 'customer/account';
					//	rb.queueLoadReel();
				}
			}
		});
		jQuery(".ui-dialog-titlebar").hide();
	},

	queueLoadReel: function(reel_id) {
		if(typeof reel_id == "undefined" && rb.getUrlParameter('reel_id')) {
			rb.reel_id = reel_id = rb.getUrlParameter('reel_id');
			// TODO find a more efficient way to ensure canvas has "settled"
			setTimeout(function(){rb.loadReel();}, 2200);
			//	setTimeout(function(){if(rb.frameHasChanges) { rb.saveReel();} } , 2200);
		} else {
			// get a fresh reel
			// queue a save reel
			rb.log("get a blank reel");
			rb.getBlankReel();
		}

	},

	loadReel: function(reel_id) {

		if(typeof reel_id == "undefined" && rb.getUrlParameter('reel_id')) {
			rb.reel_id = reel_id = rb.getUrlParameter('reel_id');
		}

		if(typeof reel_id != "undefined" && reel_id > 0) {


			rb.reel_id = reel_id;

			jQuery.ajax({
				type: "POST",
				url: rb.postUrl,
				data: {reel_id: rb.reel_id, action: 'load_reel'},
				dataType: 'json',
				success: function(retData, jqXHR) {
					//retData = jQuery.parseJSON(retData);
					rb.log("load Reel - we have success load_reel");
					//rb.log(retData);

					rb.forceLoginRedirect(retData);
					rb._recent_json = retData;

					// if we have a frame_id = set it as the active frame.
					var activeUriFrameId = rb.getUrlParameter('frame_id') || false;

					var activeUrlFrameIsCenter = false;
					rb._recent_json = retData;
					rb.loadFrameData(true);

					jQuery('#txt-reelName').val(retData.data.reel_name);
					rb.reel_id = retData.data.entity_id;


					// this is for phantom.
					//for (var property in rb.frameData) {
					for (var property=0; property < FRAME_COUNT; property++) {
						if (rb.frameData[property] != undefined) {
							var frameEntity = rb.frameData[property].entity_id;

							if(property == 0 && frameEntity && (rb.frameData[property].source_file)) {
								jQuery('#center-art-thumb').attr('src',rb.buildCurrentFrameImageUrl(true, true, frameEntity));
							}

							if(activeUriFrameId && activeUriFrameId == frameEntity) {

								// center works slightly different. we set in the function below
								if(property != 0) {
									rb.currentFrameIndex = property;
								}

								activeUrlFrameIsCenter = property == 0;

							}
						}
					}

					// updatet all frames and thumbs
					rb.updateAllFrameEntityAndThumbs();

					// phantom wants to load a specific frame
					if(activeUriFrameId) {
						rb.frameHasChanges = false;
						if(activeUrlFrameIsCenter) {
							rb.editCenterArtClick(true);
							rb.log("we have specified center art load!");
						} else {
							rb.log("we have specified frame load!" + activeUriFrameId);

							jQuery('[data-frame-entity-id="' + activeUriFrameId + '"]').click();
						}
					} else {
						rb.log("regular load!");
						rb.loadFrame();
						rb.frameHasChanges = false;

					}


				}
			});
		}

		rb.sendGaEvent('load_reel_complete', "load_reel", 0);
		rb.hideLoading();
	},


	updateAllFrameEntityAndThumbs: function(isInitialize) {

		if(typeof isInitialize == "undefined") {
			isInitialize = false;
		}

		for (var property=1; property<FRAME_COUNT; property++) {
			var frameThumbElement = jQuery('.frame-list > [data-frame-id=' + property + ' ]');
			frameThumbElement.attr('data-frame-entity-id', 0);
			frameThumbElement.css('background-image',  'none');
			if (rb.frameData[property] != undefined) {

				var frameEntity = rb.frameData[property].entity_id;
				frameThumbElement.attr('data-frame-entity-id', frameEntity);

				// TODO only updat thumb if thre is a source file? what if there is
				if(rb.frameData[property].frame_data.canvas_json && (rb.frameData[property].source_file || rb.frameData[property].background_file || rb.frameData[property].text_file)) {
					var frameThumbUrl = rb.buildCurrentFrameImageUrl(true, true, frameEntity);
					frameThumbElement.css('background-image', 'url(' + frameThumbUrl + ')').css('background-size', '100% auto');
				} else {
					frameThumbElement.css('background-image', 'none').css('background-size', '100% auto');
				}

			}

		}

		if(rb.currentFrameIndex != 0) {
			rb.setActiveThumbObjectBackground();
		}
	},

	updateThumbFromCanvasJson: function(frameData) {

		if(!frameData.entity_id || !frameData.frame_data || !frameData.frame_data.canvas_json) {
			return;

		}

		var frameThumbElement = jQuery('.frame-list > [data-frame-id=' + Number(frameData.frame_index) + ' ]')

		var tmpCanvasObject =  document.createElement("canvas");

		var tmpThumbId = "tmpCanvasThumb";
		tmpCanvasObject.id = tmpThumbId;


		// set to frame dims OR CENTER
		var maxWidth = FRAME_WIDTH;
		var maxHeight = FRAME_HEIGHT;

		tmpCanvasObject.width = maxWidth;
		tmpCanvasObject.height = maxHeight;


		if(frameData.frame_index == 0) {
			tmpCanvasObject.width = CENTER_WIDTH;
			tmpCanvasObject.height = CENTER_HEIGHT;
		}

		var resizeCanvas = new fabric.Canvas(tmpThumbId);

		resizeCanvas.width = tmpCanvasObject.width;
		resizeCanvas.height = tmpCanvasObject.height;

		var tImg = false;
		var oImg=document.createElement("img");
		oImg.onload = function() {
			resizeCanvas.loadFromJSON(frameData.frame_data.canvas_json, function() {
				// call back?

				resizeCanvas.renderAll.bind(resizeCanvas);
				resizeCanvas.calcOffset();
				resizeCanvas.deactivateAll();

				var resizeImageData = resizeCanvas.toDataURL();
				tImg = document.createElement("img");
				tImg.onload = function() {
					frameThumbElement.css('background-image', 'url(' + tImg.src + ')').css('background-size', '100% auto');
					rb.log("set from canvas");
					//	resizeCanvas.clear();
					try {
						jQuery().remove(resizeCanvas);
						jQuery().remove(tmpCanvasObject);

					} catch (Err) {
						rb.log("failure to remove");
						rb.log(Err);

					}

				};
				tImg.src = resizeImageData;

			});
		};

		oImg.src = rb.buildCurrentFrameImageUrl(false, true, frameData.entity_id);

	},

	loadFrameData: function(initializeData) {
		// TODO allow for patial updates?
		rb.frameData = new Array();
		rb.log("load ALL frame data each time.");
		rb.frameData =  rb._recent_json.data.frame_data;
	},

	getCanvas: function() {
		return this.canvas;
	},

	getCenterCanvas: function() {
		return this.centerCanvas;
	},

	renderCanvas: function(bind) {
		// TODO: set a time on last called. dont every every X seconds - ensure to queue a call in the event we  blocked this one
		//var nowtime = Math.floor((new Date().getTime()));
		//if(!rb.renderedCanvasCalled){
		//	rb.renderedCanvasCalled = nowtime;
		//} else if(nowtime - rb.renderedCanvasCalled < (rb.renderedCanvasDelay*1000)) {
		//
		//	return;
		//}
//		rb.renderedCanvasCalled = nowtime;
		//rb.frameHasChanges = true;

		//rb.log("renderCanvas: render canvas called");

		rb.bringTextToFront();
		for (var i = 0; i < rb.getCanvas()._objects.length; i++) {
			rb.getCanvas()._objects[i].setCoords();
		}

		rb.getCanvas().calcOffset();

		if(typeof bind != "undefined" && bind) {
			rb.getCanvas().renderAll.bind(rb.getCanvas());
			return;
		}

		rb.getCanvas().renderAll();


	},

	renderCenterCanvas: function(bind) {

		rb.frameHasChanges = true;

		rb.bringTextToFront();
		for (var i = 0; i < rb.getCenterCanvas()._objects.length; i++) {
			rb.getCenterCanvas()._objects[i].setCoords();
		}

		rb.getCenterCanvas().calcOffset();

		if(typeof bind != "undefined" && bind) {
			rb.getCenterCanvas().renderAll.bind(rb.getCenterCanvas());
			return;
		}
		rb.getCenterCanvas().renderAll();
	},

	getImageScaleValue: function(imgObj) {
		var initialScale = 1;
		if(imgObj.width > rb.getCanvas().width || imgObj.height > rb.getCanvas().height) {
			initialScale = imgObj.width > imgObj.height ? rb.getCanvas().height / imgObj.height :  rb.getCanvas().width/ imgObj.width ;
		}

		return initialScale;
	},

	replaceFrameImageWithHelper: function() {

		var img = new Image();
		img.onload=function() {
			if(img && img.src && rb.getActiveFrameCanvasImage()) {
				rb.getActiveFrameCanvasImage().setElement(img);
				rb.getActiveFrameCanvasImage().src = img.src;

				var initialScale = rb.getImageScaleValue(img);

				rb.currentFrameImage.scaleX = initialScale;
				rb.currentFrameImage.scaleY = initialScale;

			} else {
				rb.log("replaceFrameImageWithHelper: could not verify we have an image and its replacement");
			}
		};

		img.src=rb.buildCurrentFrameImageUrl(false, true, rb.getCurrentFrameData().entity_id);
	},

	editCenterArtClick: function(forceReload) {
		//See if the previous frame has changes
                rb.frameHasChanges = false;
                var lastCanvasHash = rb.hashCode(JSON.stringify(rb.getCanvas()));

                if(lastCanvasHash != rb.canvasHash){
                        rb.frameHasChanges = true;
                }

		if(typeof forceReload == "undefined") {
			forceReload = false;
		}

		if(rb.currentFrameIndex == 0 && !forceReload) {
			return;
		}

		rb.showLoading();

		if(rb.frameHasChanges && CUSTOMER_LOGGEDIN) {
			rb.saveandOpenCenter = true;
			rb.saveReel();
		} else  {
			rb.frameHasChanges = false;
			rb.continueOpenCenter(false);
		}

	},

	continueOpenCenter: function() {

		rb.setActiveThumbClass(true);
		rb.frameCanvas = rb.canvas;
		rb.canvas = rb.centerCanvas;

		rb.beforeCenterFrameEntityId = rb.getCurrentFrameData().entity_id;
		rb.currentFrameIndex = 0;
		rb.resetFrameTools();
		var showNow = true;
		rb.currentFrameImage = false;
		if(rb.frameData[0] != undefined && rb.frameData[0].frame_data != null && rb.frameData[0].frame_data.canvas_json != null) {
			rb.loadDataIntoCanvas(rb.centerCanvas, rb.frameData[0].frame_data, true);

			showNow = false;
		}
        
        	rb.getCanvas().overlayImage.left = rb.getCanvas().getWidth()/2;
        	rb.getCanvas().overlayImage.top = rb.getCanvas().getHeight()/2;

        	rb.getCanvas().overlayImage.width = rb.getCanvas().getWidth();
        	rb.getCanvas().overlayImage.height = rb.getCanvas().getHeight();
        	rb.renderCanvas();

		jQuery('#edit-frame').hide();
		jQuery('#center-art-canvas').show();
		if(showNow) {
			rb.hideLoading();
		}

		setTimeout(function(){rb.canvasHash = rb.hashCode(JSON.stringify(rb.getCenterCanvas()));}, 2200);
	},

	continueSaveCenter:  function() {

		rb.log("continueSaveCenter : canvas shuffle");
		rb.currentFrameIndex = rb.getFrameIndexByFrameId(rb.beforeCenterFrameEntityId)  || 1;
		rb.centerCanvas = rb.canvas;
		rb.canvas = rb.frameCanvas;
		jQuery('#edit-frame').show();
		rb.resetFrameTools();
		jQuery('#center-art-canvas').hide();

		rb.resetFrameTools();
		rb.log(" changing to " + rb.getCurrentFrameIndex());
		jQuery('[data-frame-id="' + rb.getCurrentFrameIndex() + '"]').click();
		return;
	},

	doneEditCenterArtClick: function() {
		rb.showLoading();
		jQuery('#center-art-thumb').attr('src', rb.getGenerateCanvasThumb());
		rb.log("doneEditCenterArtClick waiting");
		setTimeout(function(){rb.proceedDoneEditCenter();}, CENTER_ART_DELAY_TIME);
	},

	proceedDoneEditCenter: function() {
		rb.log("proceedDoneEditCenter running");

		rb.showLoading();
		rb.resetTextTools();
		var hasPreviousCanvasData = (rb.frameData[0] != undefined && rb.frameData[0].frame_data != null && rb.frameData[0].frame_data.canvas_json != null);
		// we only send center art if there were changes...
		var centerHasChange = true;
		rb.saveCenterAndChangeFrame = true;


		try {
			centerHasChange = JSON.stringify(rb.centerCanvas.toJSON()) != rb.frameData[0].frame_data.canvas_json;
		} catch (Err) {
			rb.log("proceedDoneEditCenter exception");
			rb.log(Err, true);
		}

		if(!hasPreviousCanvasData || centerHasChange) {
			rb.log("proceedDoneEditCenter save reel");
			rb.saveReel();
		} else {
			rb.log("proceedDoneEditCenter => continueSaveCenter");
			rb.continueSaveCenter();
		}
	},

	buildCurrentFrameImageUrl: function(isThumb, isJpg, frameEntityId, noBaseImage) {

		if(typeof frameEntityId == "undefined") {
			frameEntityId = rb.getCurrentFrameData().entity_id;
		}

		if(typeof nobaseImage == "undefined") {
			noBaseImage = false;
		}


		var url =  BASE_URL + "reelbuilderCb/?i3d_image=frame&reel_id=" + rb.reel_id + "&frame_id=" + frameEntityId;

		if(isThumb) {
			url += "&thumb=true";
		}
		if(isJpg) {
			url += "&jpg=true";
		}

		var json = rb._recent_json ? JSON.stringify(rb._recent_json) :  Math.random();
		url += "&sf_hash=" + rb.hashCode(json);
		return url;
	},

	getActiveFrameThumbnail: function() {
		return rb.getFrameThumbnail(rb.getCurrentFrameIndex());
	},

	getFrameThumbnail: function(x) {
		return jQuery('.frame-list > [data-frame-id='+ Number(x) +' ]');
	},

	clearActiveThumbObjectBackground: function() {
		rb.getActiveFrameThumbnail().css('background-image', 'none');
	},


	clearThumbObjectBackground: function(eleX) {
		eleX.css('background-image', 'none');
	},

	getGenerateCanvasThumb: function() {

		// hide overlay

		var overlayObject =  jQuery.extend(true, {}, rb.getCanvas().overlayImage);
	//	var bgColor =  rb.getCanvas().backgroundColor;

		var thumbPath = false;
		rb.getCanvas().overlayImage = false;
	//	rb.getCanvas().backgroundColor = false;

		rb.renderCanvas();
		thumbPath = rb.canvas.toDataURL({
			format: 'png',
			left: 0,
			top: 0,
			//multiplier: THUMB_WIDTH/FRAME_WIDTH
			multiplier:1
		});
		rb.renderCanvas();
		rb.getCanvas().overlayImage = overlayObject;
	//	rb.getCanvas().backgroundColor = bgColor;
		rb.updateCanvasOverlay();
		rb.renderCanvas();
		return thumbPath;
	},

	setActiveThumbObjectBackground: function(frameId) {


		if(rb.getUrlParameter('process_frame_image')) {
			// the phontom needs nothing
			return;
		}
		// as we do it with canvas; it has to be the active
		frameId = rb.currentFrameIndex;
		rb.log("we have actrive thumb setActiveThumbObjectBackground " + frameId);

		if(frameId == 0) {
			return;
		}

		if(rb.getCanvas()._objects.length > 0) {


			var thumbPath = rb.getGenerateCanvasThumb();
			rb.log(' update thumb');
			rb.getFrameThumbnail(frameId).css('background-image', 'url(' +
			thumbPath + ')').css('background-size', '100% auto');
//		rb.getActiveFrameThumbnail().css('background-image', 'url(' + thumbPath + ')').css('background-size', '100% auto');
			rb.getFrameThumbnail(frameId).thumbnail = thumbPath;
		}
	},

	setActiveThumbClass: function(isCenter)
	{
		jQuery(".filmstrip-frame-active").removeClass('filmstrip-frame-active');
		jQuery('.centerlabel-container').removeClass('center-art-active');

		if(isCenter) {
			jQuery('.centerlabel-container').addClass('center-art-active');
		}else {
			jQuery('.frame-list > [data-frame-id=' + Number(rb.currentFrameIndex) + ' ]').addClass('filmstrip-frame-active');
		}
	},

	getActiveFrameCanvasImage: function() {
		if(!rb.currentFrameImage) {
			rb.log("getActiveFrameCanvasImage:  we need to go find the active frame image!");
		}
		return rb.currentFrameImage;
	},

	getFrameIndexByFrameId: function(frameId) {

		for (var property=0; property<FRAME_COUNT; property++) {
			if (rb.frameData[property] != undefined && frameId == rb.frameData[property].entity_id) {
				return rb.frameData[property].frame_index;
			}
		}
		rb.log("getFrameIndexByFrameId:  we failed to find the active frame by entity id!");
		return null;
	},

	getCurrentFrameDataPosition: function() {
		return rb.getFrameDataPosition(rb.getCurrentFrameIndex());
	},

	getCurrentFrameDataPositionByEntityId: function(entity_id) {
		for (var property=0; property<FRAME_COUNT; property++) {
			if (rb.frameData[property] != undefined && entity_id == rb.frameData[property].entity_id) {
				return property;
			}
		}
		rb.log("getCurrentFrameData: failed to find frame");
		return {};
	},

	getFrameDataPosition: function(frame_index) {

		for (var property=0; property<FRAME_COUNT; property++) {
			if (rb.frameData[property] != undefined && frame_index == rb.frameData[property].frame_index) {
				return property;
			}
		}
		rb.log("getCurrentFrameData: failed to find frame");
		return {};
	},

	getCurrentFrameData: function() {

		var property = rb.getCurrentFrameDataPosition();
		if(property > 0 ||  property === 0) {
			return rb.frameData[property];
		}
		rb.log("getCurrentFrameData: failed to find frame");
		return {};
	},

	getCurrentFrameIndex: function() {
		return this.currentFrameIndex;
	},

	setCurrentFrameIndex : function(index) {
		// update the classes so we can tell which is active
		this.currentFrameIndex = index;
	},

	loadFrame: function() {

		rb.log("loadFrame: reset tools on load!");
		rb.resetFrameTools();
		if(rb.getCurrentFrameData() &&
			rb.getCurrentFrameData().frame_data &&
			rb.getCurrentFrameData().frame_data.canvas_json) {
			// load the dat ato canvas.

			rb.loadDataIntoCanvas(rb.canvas, rb.getCurrentFrameData().frame_data, false);
		} else if(!rb.getCurrentFrameData().frame_data &&
			rb.getCurrentFrameData().source_file) {
			// we have an image but canvas didnt get a change load it. lets fix it.
			var imgObj = new Image();
			imgObj.onload = function() {
				rb.addImageToCanvas(imgObj);
				rb.hideLoading(false);

			};

			imgObj.src = rb.buildCurrentFrameImageUrl(false, true, rb.getCurrentFrameData().entity_id);

		} else {
			rb.hideLoading(false);
		}
		rb.frameHasChanges = false;
		//Store the canvas hash
		setTimeout(function(){rb.canvasHash = rb.hashCode(JSON.stringify(rb.getCanvas()));}, 2200);
	},

	showAjaxLoadingProgress: function(event) {
		// TODO: not implemented - could be useful to show the user.
		// https://www.developphp.com/video/JavaScript/File-Upload-Progress-Bar-Meter-Tutorial-Ajax-PHP
		// https://github.com/drogus/jquery-upload-progress
		// http://web.archive.org/web/20120414125425/http://t.wits.sg/2008/06/25/howto-php-and-jquery-upload-progress-bar
		function progressHandler(event){
			_("loaded_n_total").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
			var percent = (event.loaded / event.total) * 100;
			_("progressBar").value = Math.round(percent);
			_("status").innerHTML = Math.round(percent)+"% uploaded... please wait";
		}

	},

	updateCanvasOverlay: function() {
		var overlayimgObj = new Image();
		overlayimgObj.onload = function () {
			rb.getCanvas().setOverlayImage(overlayimgObj.src, function() {
				rb.getCanvas().overlayImage.left = rb.getCanvas().getWidth()/2;
				rb.getCanvas().overlayImage.top = rb.getCanvas().getHeight()/2;
				rb.getCanvas().overlayImage.width = rb.getCanvas().getWidth();
				rb.getCanvas().overlayImage.height = rb.getCanvas().getHeight();
				setTimeout(function(){rb.renderCanvas();}, 1200);
			});
		};
		overlayimgObj.src = rb.getCurrentFrameIndex() == 0 ? CENTER_CANVAS_MASK : CANVAS_MASK;

	},

	loadDataIntoCanvas: function(canvas, json, isCenter) {

		canvas.clear();

		rb.resetFrameTools();
		rb.currentFrameImage = false;
		canvas.loadFromJSON(json.canvas_json, function() {

			rb.skipCanvasUpdate = true;

			var brightness = null;
			var contrast = null;
			var sepia = false;
			var greyScale = false;
			var angle = (ROTATE_DEFAULT / ROTATE_MODIFIER ) - ROTATE_DIFF;
			var scale = 1;
			for (var i = 0; i < canvas._objects.length; i++) {

				if(canvas._objects[i].type != "image") {
					continue;
				}
				// we only support a single image at this time.
				rb.currentFrameImage = canvas._objects[i];
				scale = rb.currentFrameImage.scaleX;
				angle = rb.currentFrameImage.angle;
				for (var j = 0; j < rb.currentFrameImage.filters.length; j++) {
					if(rb.currentFrameImage.filters[j].type == 'Brightness') {
						brightness = rb.currentFrameImage.filters[j].brightness;
					} else  if(rb.currentFrameImage.filters[j].type == 'Sepia2' || rb.currentFrameImage.filters[j].type == 'Sepia') {
						sepia = true;
					} else  if(rb.currentFrameImage.filters[j].type == 'Grayscale') {
						greyScale = true;
					} else if(rb.currentFrameImage.filters[j].type == 'Contrast') {
						contrast = rb.currentFrameImage.filters[j].contrast;
					}
				}
				// again only 1 image
				break;
			}

			jQuery("#slider-rotate").slider('option','value', (angle + ROTATE_DIFF) * ROTATE_MODIFIER);
			jQuery("#slider-scale").slider('option','value', scale * SCALE_MODIFIER);
			jQuery( "#slider-brightness" ).slider('option','value', brightness);
			jQuery( "#slider-contrast" ).slider('option','value', contrast);

			rb.updateCanvasOverlay();

			rb.renderCanvas();

			// defaults to color for now.
			if(sepia) {
				jQuery( "#rad-sepia" ).click();
			} else if(greyScale) {
				jQuery( "#rad-bw" ).click();
			} else {
				jQuery( "#rad-fullColor" ).click();
			}

			rb.skipCanvasUpdate = false;
			if(isCenter) {

				jQuery('#edit-frame').hide();
				jQuery('#center-art-canvas').show();
				rb.hideLoading();
			}

			// if we are in generation mode = wait for the image to be loaded.
			if(rb.getUrlParameter('process_frame_image')) {
				var img = new Image();
				img.onload = function() {
					if(img && img.src && rb.currentFrameImage) {
						rb.setPhantomSuccess();
					} else {
						rb.log("invalid image or no image?...");
						rb.setPhantomSuccess();
					}
				};
				img.onerror = function() {
					rb.log("phantom precache error error...");
					rb.setPhantomSuccess();
				};

				var tmpSrc = rb.buildCurrentFrameImageUrl(false, false);
				rb.log(" in phantom cache " + tmpSrc);
				img.src = tmpSrc;
			}

			if(!isCenter) {
				rb.setActiveThumbObjectBackground();
			}

			rb.sendGaEvent('load_frame_' + rb.getCurrentFrameData().frame_index, "load_frame", 0);
			rb.frameHasChanges = false;
			rb.hideLoading(false);
			rb.log("loading canvas...");

            rb.renderCanvas();
		});
	},

	setPhantomSuccess: function() {
		rb._completedPhantomJs = true;
		rb.log("phantom is back!!");
	},

	setActiveFrameImageContrast: function(event, ui) {
		//	rb.log("  contrast update " + ui.value);
		if(!rb.skipCanvasUpdate && rb.currentFrameImage) {
			var number = Number(ui.value);
			var filter = rb.getActiveImageFilter("Contrast");
			if(!filter) {
				rb.log(" didnt find contrast fitler.. adding??!");
				filter = new fabric.Image.filters.Contrast({});
				rb.currentFrameImage.filters.push(filter);
			}
			filter.contrast = number;
			rb.applyImageFilters();
		}
	},

	getActiveImageFilter: function(which) {
		for (var j = 0; j < rb.currentFrameImage.filters.length; j++) {
			if(rb.currentFrameImage.filters[j].type == which) {
				return rb.currentFrameImage.filters[j];
			}
		}
		return false;
	},

	applyImageColorFilter: function(e, textTarget) {

		if(!rb.currentFrameImage) {
			return false;
		}

		if(typeof textTarget == "undefined") {
			textTarget = e.target.id;
		}

		if(!rb.skipCanvasUpdate && !rb.filtersProcessing) {
			rb.filtersProcessing = true;
			setTimeout(function(){ rb.filtersProcessing = false; }, 900);

			rb.log("applying image filters to canvas image");
			var filter = false;
			var filters = [];
			if(textTarget == 'rad-bw') {
				filter = new fabric.Image.filters.Grayscale();
			} else if (textTarget == 'rad-sepia') {
				filter = new fabric.Image.filters.Sepia2();
			} else if (textTarget == "rad-fullColor") {
				filter = false;
			} else {
				rb.log("unsure of how to process the event");
				rb.log(e);
			}

			var filters = [];
			if(filter) {
				filters.push(filter);
			}

			for (var j = 0; j < rb.currentFrameImage.filters.length; j++) {
				if(rb.currentFrameImage.filters[j].type == 'Brightness' || rb.currentFrameImage.filters[j].type == 'Contrast') {
					filters.push(rb.currentFrameImage.filters[j]);
				}
			}

			rb.currentFrameImage.filters = [];
			rb.currentFrameImage.filters = filters;
			rb.applyImageFilters();
		}
		e.stopPropagation();
	},

	setActiveFrameImageBrightness: function(event, ui) {
		if(!rb.skipCanvasUpdate && rb.currentFrameImage) {
			var number = Number(ui.value);
			var filter = rb.getActiveImageFilter("Brightness");
			if(!filter) {
				rb.log(" didnt find brightness fitler.. adding??!");
				filter = new fabric.Image.filters.Brightness({});
				rb.currentFrameImage.filters.push(filter);
			}
			filter.brightness = number;
			rb.applyImageFilters();
		}
	},

	applyImageFilters: function() {
		rb.currentFrameImage.applyFilters(rb.getCanvas().renderAll.bind(rb.getCanvas()));
	},

	setActiveFrameImageRotate: function(event, ui) {
		if(!rb.skipCanvasUpdate && rb.currentFrameImage) {
			var number = (ui.value / ROTATE_MODIFIER) - ROTATE_DIFF;
			//rb.currentFrameImage.setAngle(number);
			rb.currentFrameImage.angle = number;
			rb.renderCanvas();
			rb.bringTextToFront();
		}
	},

	setActiveFrameImageScale: function(event, ui) {
		//	rb.log(" scale update " + ui.value);
		if(!rb.skipCanvasUpdate && rb.currentFrameImage && Number(ui.value)) {
			var number = Number(ui.value)/SCALE_MODIFIER;
			rb.currentFrameImage.scaleX = number;
			rb.currentFrameImage.scaleY = number;
			rb.renderCanvas();
			rb.bringTextToFront();
		}
	},

	saveReel: function() {
		rb.log(" SaveReel fired ... ");
		if(rb.getUrlParameter('process_frame_image')) {
			// the phontom needs no GA
			rb.log(" SaveReel skipped ... ");
			rb.reelSaveWasSuccess = true;
			rb.hideLoading();
			return;
		}

		rb.showLoading();

		rb.setActiveThumbObjectBackground();

		rb.continueSaveReel();
	},

	getPreparedActiveCanvasJson: function(frameId) {

		var canvasJson = rb.getCanvas().toJSON();
		if(typeof frameId == "undefined") {
			frameId = rb.getCurrentFrameData().entity_id;
		}

		for (var i = 0; i < canvasJson.objects.length; i++) {
			try {
				// this indicates its an image and not text..
				if(String(canvasJson.objects[i].type) == "image" && canvasJson.objects[i].src.indexOf('http:') != 0) {

					canvasJson.objects[i].src = rb.buildCurrentFrameImageUrl(false, true, frameId, true);
					rb.log("replaced URL before frame save " + canvasJson.objects[i].src);
				}
			} catch(Err) {
				rb.log(" failed to correct url!!?");
				rb.log(Err, true);
			}
		}
		return canvasJson;
	},

	getBlankReel: function() {
		rb.log("getBlankReel: we have a blank reel");
		rb.log("init blank reel ");
		var xData = {};

		xData.reel_id = -1;
		xData.action = 'init_reel';

		rb.log(xData);
		jQuery.ajax({
			type: "POST",
			url: rb.postUrl,
			data: xData,
			dataType: 'json',
			complete: function(retData, jqXHR) {

				rb.log("getBlankReel - we have complete ");

				rb.hideLoading();
			},

			success: function(retData, jqXHR) {
				//retData = jQuery.parseJSON(retData);
				rb.log("getBlankReel - we have success");

				rb.log(retData);
				rb._recent_json = retData;
				rb.forceLoginRedirect(retData);
				rb.updateUrlReelId();

				rb.loadFrameData(true);
				rb.updateAllFrameEntityAndThumbs(true);

			}
		});
	},

	frameHasText: function() {
		for (var i = 0; i < rb.getCanvas()._objects.length; i++) {
			if (rb.getCanvas()._objects[i].type == "text") {
				return true;
			}
		}
		return false;
	},

	continueSaveReel: function() {
		rb.log(" continueSaveReel fired");

		if(rb.getUrlParameter('process_frame_image')) {
			rb.log(" should not get here", true);
			rb.hideLoading();
			return;
		}

		if(!CUSTOMER_LOGGEDIN) {
			rb.log("we really have not dealt with customers not being loggedin - we can handle it at some point if we determine. ");
			document.location.reload();
		}


		if(rb.reel_id && !jQuery('#txt-reelName').val()) {
			var today = new Date();
			jQuery('#txt-reelName').val("Unnamed Reel from " + today.toDateString() + ' - ' + today.getHours() + ':' + today.getMinutes());
		}

		var xData = {};
		xData.frame_data = rb.frameData;
		var current_frame_index = rb.getCurrentFrameIndex();
		var currentFrameDataPosition = rb.getCurrentFrameDataPosition();
		xData.action = 'save_reel';
		xData.reel_id = rb.reel_id;
		xData.current_frame_index = current_frame_index;
		xData.current_frame_entity_id = rb.getCurrentFrameData().entity_id;
		xData.reel_name =  jQuery('#txt-reelName').val();

		xData.isBlankReel = rb.reel_id < 0;



//		xData.source_file = rb.getCurrentFrameData() && rb.getCurrentFrameData().source_file ? rb.getCurrentFrameData().source_file : ONE_PIXEL_PNG; //ONE_PIXEL_PNG
		//rb.log(" saving source " + xData.source_file  );

		if(!xData.frame_data[currentFrameDataPosition].frame_data) {
			xData.frame_data[currentFrameDataPosition].frame_data = {'canvas_json': false};
		}
		var activeCanvasJson = JSON.stringify(rb.getPreparedActiveCanvasJson());
		xData.frame_data[currentFrameDataPosition].frame_data.canvas_json = activeCanvasJson;
		if(rb.frameData[currentFrameDataPosition] && rb.frameData[currentFrameDataPosition].frame_data) {
			rb.frameData[currentFrameDataPosition].frame_data.canvas_json = activeCanvasJson;
		}

		//See if we need to send text

		if(rb.frameHasText()) {
			var textData = rb.getTextPng();
			xData.text = textData;
		}

		rb.log("save frame data");

		jQuery.ajax({
			type: "POST",
			url: rb.postUrl,
			data: xData,
			dataType: 'json',
			complete: function(retData, jqXHR) {

				rb.log("saveFRame - we have complete ");

				if(rb._recent_json.reload_reel == true) {

				}
				if(rb.saveAndExitBit) {
					rb.log("save and exit no need for anything else");
					return;
				}

				rb.frameHasChanges = false;
				rb.unsavedReorder = false;

				if(!rb.reelSaveWasSuccess) {
					// TODO the reel was not saved; do we reload the page?
					rb.log(" the reel was not successfully save before oncomplete was called for save_frame", true);
				}

				rb.reelSaveWasSuccess = false;

				jQuery("#imgLoader").val("");

				if(rb.saveandOpenCenter) {
					rb.sendGaEvent('save_reel_open_center', "save_reel", 0);

					rb.continueOpenCenter();
					rb.saveandOpenCenter = false;
					return;
				}

				if(rb.saveCenterAndChangeFrame) {
					rb.log("we have complete and saveCenterAndChangeFrame " + rb.saveCenterAndChangeFrame);
					rb.sendGaEvent('save_reel_center', "save_reel", 0);

					rb.continueSaveCenter();
					rb.saveCenterAndChangeFrame = false;
					return;
				}

				if(rb.saveandChangeFrameBit != false) {
					rb.sendGaEvent('save_reel_change_frame', "save_reel", 0);
					rb.log("we have complete and saveandChangeFrameBit" + rb.saveandChangeFrameBit);

					rb.continueChangeCurrentFrame(rb.saveandChangeFrameBit);
					rb.saveandChangeFrameBit = false;
					return;
				}

				if(rb.saveandContinuePreview) {
					rb.sendGaEvent('save_reel_preview', "save_reel", 0);

					rb.saveandContinuePreview = false;
					rb.processPreviewReel();
					return;
				}
				rb.enableReorder();
				rb.hideLoading(retData);
			},
			success: function(retData, jqXHR) {
				//retData = jQuery.parseJSON(retData);
				rb.log("saveFRame - we have success");
				if(rb.saveAndExitBit) {
					rb.log("save and exit no need for anything else");
					rb.sendGaEvent('save_reel_exit', "save_reel", 0);
					document.location.href = BASE_URL + 'customer/account';
					return;
				}

				rb.log(retData);
				rb._recent_json = retData;
				rb.loadFrameData(true);

				rb.updateUrlReelId();
				rb.processJsonReturn(retData, retData.posted_frame_index);

				//rb.hideLoading(retData);
				rb.reelSaveWasSuccess = true;
			}
		});
	},

	forceLoginRedirect: function(retData) {

		if(!retData.success && typeof retData.login_redirect != undefined ) {
			var redirect = String(retData.login_redirect);
			if(!redirect || redirect == 'undefined' || redirect == undefined) {
				redirect = BASE_URL + 'customer/account';
			}
			document.location.href = redirect;
			return;
		}
	},

	processJsonReturn: function(retData, frameIndex) {

		rb.log("processJsonReturn");

		if(!rb.reel_id) {
			rb.reel_id = retData.data.entity_id;
		}

		if(retData.reload_reel == true) {
			// force a reload here cancel everything else
			rb.log("processJsonReturn: force a reload - server did not match");
		}
		rb.forceLoginRedirect(retData);

	},

	preCacheFrameBackgroundSetCanvasImage : function() {
		var oImg=document.createElement("img");

		oImg.src = rb.buildCurrentFrameImageUrl(false, false, rb.getCurrentFrameData().entity_id);
		document.body.appendChild(oImg);
	},

	bringTextToFront: function() {

		for (var i = 0; i < rb.getCanvas()._objects.length; i++) {
			try {
				// this indicates its an image and not text..
				if(String(rb.getCanvas()._objects[i]._originalElement) != "undefined") {
					rb.getCanvas()._objects[i].sendToBack();
				}
			} catch(Err) {
				rb.log(" failed to loop?");
				rb.log(Err, true);
			}
		}

	},

	loadFabricImageFrame: function(imgObj, imgData) {
		var image = new fabric.Image(imgObj);

		var initialScale = 1;
		if(imgObj.width > rb.getCanvas().width || imgObj.height > rb.getCanvas().height) {
			initialScale = imgObj.width > imgObj.height ? rb.getCanvas().height / imgObj.height :  rb.getCanvas().width/ imgObj.width ;
		}
		rb.resetImageTools(initialScale);

		if(typeof imgData == undefined || typeof imgData == 'undefined') {
			imgData = {
				left: rb.getCanvas().getWidth()/2,
				top: rb.getCanvas().getHeight()/2,
				padding: CANVAS_PAD_CONST,
				cornersize: CANVAS_PAD_CORNER,
				centeredScaling: true
				//	originX: 'center',
				//	originY: 'center'
			};
		}

		imgData.scaleX = initialScale;
		imgData.scaleY = initialScale;

		image.set(imgData);
		rb.frameHasChanges = true;
		return image;
	},

	hashCode: function(s){
		return s.split("").reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a},0);
	},

	disableReorder: function(msg, timerOut) {
		rb.log("disabled reorder");
		jQuery('.reorder-strip-container').append(maskOverlay);
		var notAvailable = '<div class="frame-list-notice"><p class="frame-list-notice-wrap"><span>' + msg + '</span></p></div>';
		jQuery('.reorder-strip-container .ui-widget-overlay').after(notAvailable);
		jQuery('.centerlabel-container').append(centerOverlay.css("position","absolute"));

		if(typeof timerOut != "undefined") {
			setTimeout(function(){  rb.unBlockReorder(); rb.enableReorder(); }, timerOut);
		}
	},

	enableReorder: function(forceAllow) {
		if(rb.reorderIsBlocked && !forceAllow) {
			rb.log("reorder blocked... ");
			return;
		}

		rb.log("enabled reorder");
		jQuery('.reorder-strip-container .ui-widget-overlay, .frame-list-notice').remove();
		jQuery('.centerlabel-container .ui-widget-overlay').remove();
	},

	blockReorder: function() {
		rb.reorderIsBlocked = true;
	},

	unBlockReorder: function() {
		rb.reorderIsBlocked = false;
		rb.enableReorder(true);
	},

	saveNewImage: function(encodedImage) {

		this.log("we have a call  to save image.");
		// might be blocked by image message
		if(!rb.reorderIsBlocked) {
			rb.disableReorder(MSG_UPLOADING_IMAGES);
			rb.blockReorder();
		}

		var xData = {};
		xData.reel_id = rb.reel_id;
		xData.frame_id = rb.getCurrentFrameData().entity_id;
		xData.current_frame_index = rb.getCurrentFrameIndex();
		xData.action = 'save_image';
		xData.image = encodedImage;

		// we add aplaceholder for now.
		rb.frameData[rb.getCurrentFrameDataPosition()].source_file = ONE_PIXEL_PNG;
		rb.log("saveNewImage: we have post data ");
		rb.log(JSON.stringify(xData));
		jQuery.ajax({
			type: "POST",
			url: rb.postUrl,
			data: xData,
			dataType: 'json',
			complete: function(retData, jqXHR) {
				rb.enableReorder();
			},
			success: function(retData, jqXHR) {
				//retData = jQuery.parseJSON(retData);
				rb.log("saveNewImage: we have success save_image");
				//	rb.log(JSON.stringify(retData));
				rb._recent_json = retData;
				rb._save_image_recent_json = retData;
				rb.updateUrlReelId();

				if(!retData.success) {
					rb.log("saveNewImage: we have an error  saving an image " + retData.message, true);
					alert(" there was a problem saving your image, please refresh your page and try again");
					document.reload();
					return;
				}
				rb.sendGaEvent('upload_image_success', "upload_image", 0);

				if(rb.reorderIsBlocked != BLOCKED_VIA_IMAGE_SIZE) {
					rb.unBlockReorder();
				}
				rb.hideLoading();
				rb.processJsonReturn(retData, retData.data.posted_frame_index);

				//Set the canvas data if not center.
				// TODO why dont we set if it center?
				var activeIndex = rb.getCurrentFrameIndex();
				if(activeIndex != 0) {
					var activeCanvasJson = JSON.stringify(rb.getPreparedActiveCanvasJson());
					rb.frameData[activeIndex].frame_data.canvas_json = activeCanvasJson;

					// stick with it?
					if(rb.getCurrentFrameData().entity_id == retData.data.posted_frame_entity_id) {
						rb.replaceFrameImageWithHelper();
						rb.renderCanvas();
					}
				}
			}
		});
		rb.log("saveNewImage: we have a call  posted image.");
		return true;
	},

	setupCenterCanvasBits: function() {

		fabric.Object.prototype.originX = fabric.Object.prototype.originY = 'center';
		fabric.Object.prototype.hasControls = false;
		// disables group selection
		rb.getCenterCanvas().selection = false;
		rb.getCenterCanvas().setBackgroundColor('black');
		//preserveObjectStacking this might help with text falling behind the images.

		var overlayimgObj = new Image();
		overlayimgObj.src = CENTER_CANVAS_MASK;
		overlayimgObj.onload = function () {
			rb.getCenterCanvas().setOverlayImage(overlayimgObj.src, function() {
				rb.getCenterCanvas().overlayImage.left = rb.getCenterCanvas().getWidth()/2;
				rb.getCenterCanvas().overlayImage.top = rb.getCenterCanvas().getHeight()/2;
				rb.getCenterCanvas().overlayImage.width = rb.getCenterCanvas().getWidth();
				rb.getCenterCanvas().overlayImage.height = rb.getCenterCanvas().getHeight();
				setTimeout(function(){rb.renderCenterCanvas();}, 1200);
			});
		};

		rb.getCenterCanvas().on('object:selected', function() {

			if(rb.getCurrentFrameIndex() == 0) {
				rb.log("update from selection CENTER ");
				rb.updateTextControls(rb.getCenterCanvas());
			}
		});

		rb.getCenterCanvas().on('selection:cleared', function() {

			if(rb.getCurrentFrameIndex() == 0) {
				rb.log("update from selection CENTER ");
				rb.updateTextControls(rb.getCenterCanvas());
			}
		});

		rb.renderCenterCanvas();
	},

	setupCanvasBits: function() {

		fabric.Object.prototype.originX = fabric.Object.prototype.originY = 'center';
		fabric.Object.prototype.hasControls = false;
		// disables group selection
		rb.getCanvas().selection = false;
		rb.getCanvas().setBackgroundColor('black');
		//preserveObjectStacking this might help with text falling behind the images.

		var overlayimgObj = new Image();
		overlayimgObj.onload = function () {
			rb.getCanvas().setOverlayImage(overlayimgObj.src, function() {
				rb.getCanvas().overlayImage.left = rb.getCanvas().getWidth()/2;
				rb.getCanvas().overlayImage.top = rb.getCanvas().getHeight()/2;
				rb.getCanvas().overlayImage.width = rb.getCanvas().getWidth();
				rb.getCanvas().overlayImage.height = rb.getCanvas().getHeight();
				setTimeout(function(){rb.renderCanvas();}, 1200);
			});
		};
		overlayimgObj.src = CANVAS_MASK;


		// TODO text drag should have a binding box so it cannot go outside of the placement / cut off area
		// on last attempt it created issues of disabling drag completely
//http://stackoverflow.com/questions/19979644/set-object-drag-limit-in-fabric-js
		//rb.textDragBox = new fabric.Rect({
		//	fill: "none",
		//	width: rb.getCanvas().getWidth() - CANVAS_TEXT_DRAG_BLEED,
		//	height: rb.getCanvas().getHeight() - CANVAS_TEXT_DRAG_BLEED,
		//	left: rb.getCanvas().getWidth()/2,
		//	top: rb.getCanvas().getHeight()/2,
		//	hasBorders: false,
		//	hasControls: false,
		//	lockMovementX: true,
		//	lockMovementY: true,
		//	evented: false,
		//	stroke: "red",
		//	opacity: 0
		//});

//		rb.getCanvas().add(rb.textDragBox);

		// text issue potential fix
		//	rb.getCanvas().on('after:render', function(){ rb.getCanvas().calcOffset(); });

		//rb.getCanvas().on('touch:gesture',function(event) {
		//	isGestureEvent = true;
		//	rb.log("we have gesture" +  rb.geCanvas().getActiveObject().type);
		//
		//	// if active is text cancel out.
		//	// iff its an image update controles BUT  do nott update canvas.
		//	// disable canvas updates.
		//	// update tools.
		//
		//});

		rb.log("updating CXAVNAS OBSERVERS");
		rb.getCanvas().on("object:modified", function(e) {
			rb.frameHasChanges = true;
			if(rb.getCanvas() && rb.getCanvas().getActiveObject() != null && rb.getCanvas().getActiveObject().type == "text") {

				if(rb.getCanvas().getActiveObject().angle) {
					rb.log("object   MODIFIED  - reset text agle.." );
					rb.getCanvas().getActiveObject().angle = 0;
				}

				if(rb.getCanvas().getActiveObject().scaleX || rb.getCanvas().getActiveObject().scaleY) {
					rb.log("object   MODIFIED  - reset text scale.." );
					rb.getCanvas().getActiveObject().scaleX = 1;
					rb.getCanvas().getActiveObject().scaleY = 1;
				}

			} else {
				// update controls..
				var angle = (rb.getCanvas().getActiveObject().angle  + ROTATE_DIFF) * ROTATE_MODIFIER;
				var scale = rb.getCanvas().getActiveObject().scaleX * SCALE_MODIFIER;
				if(angle < MIN_ANGLE) {
					angle = MIN_ANGLE;
				}

				if(angle > MAX_ANGLE) {
					angle = MAX_ANGLE;
				}

				if(scale < MIN_SCALE) {
					scale = MIN_SCALE;
				}

				if(scale > MAX_SCALE) {
					scale = MAX_SCALE;
				}

				jQuery("#slider-rotate").slider('option','value', angle);
				jQuery("#slider-scale").slider('option','value', scale);

				//	rb.log("object   MODIFIED  - SCALE.." +    );
				//	rb.log("object   MODIFIED  - angle.." +   );
			}
		});


		rb.getCanvas().on('object:selected', function() {
			if(rb.getCurrentFrameIndex() != 0) {
				rb.updateTextControls(rb.getCanvas());
				rb.setActiveThumbObjectBackground();
			}
		});

		rb.getCanvas().on('selection:cleared', function() {
			if(rb.getCurrentFrameIndex() != 0) {
				//	rb.log("selection:cleared");
				rb.updateTextControls(rb.getCanvas());
				//rb.setActiveThumbObjectBackground();
			}
		});
		//	rb.getCanvas().on("object:moving", function() { rb.enforceTextDragLimits(); });
		rb.renderCanvas();
	},

	updateTextControls: function(canvas) {

		// we have an observer on the center canvas...
		if(typeof canvas == "undefined") {
			return;
		}

		rb.skipTextUpdate = true;
		if(canvas && canvas.getActiveObject() != null && canvas.getActiveObject().type == "text") {

			rb.log("updateTextControls tools" + canvas.getActiveObject().fontFamily);
			jQuery("#txt-reelText").val(canvas.getActiveObject().text);


			rb.forceUpdateFontDdDisplay(canvas.getActiveObject().fontFamily, true);

			rb.log("updateTextControls tools" + canvas.getActiveObject().fill);
			jQuery("input[value='"+canvas.getActiveObject().fontSize+"']").next().click();
			jQuery("input[value='"+canvas.getActiveObject().fill+"']").next().click();

		} else {
			//	rb.log("reset text tools  on select");
			rb.resetTextTools();
		}
		rb.skipTextUpdate = false;
	},

	resetTextTools: function() {
		rb.skipTextUpdate = true;
		if(rb.isActiveObjectText()) {
			//	rb.log(" deselct then selected text. or reselected");
			rb.updateTextControls();
			return;
		}
		jQuery("#white").click();
		jQuery('#rad-font-size3').click();
		jQuery("#txt-reelText").val('');
		jQuery('#txt-reelText').attr('title', '');
		rb.skipTextUpdate = false;

	},

	resetImageTools: function(initialScape) {

		if(typeof initialScape == "undefined") {
			initialScape = SCALE_DEFAULT;
		}
		rb.skipCanvasUpdate = true;
		// reset tools here
		jQuery( "#rad-fullColor" ).click();
		jQuery("#slider-rotate").slider('option','value',ROTATE_DEFAULT);
		jQuery("#slider-scale").slider('option','value', initialScape * SCALE_MODIFIER);
		jQuery( "#slider-brightness" ).slider('option','value', BRIGHTNESS_DEFAULT);
		jQuery( "#slider-contrast" ).slider('option','value', CONTRAST_DEFAULT);
		rb.skipCanvasUpdate = false;
	},

	resetFrameTools: function() {
		rb.resetTextTools();
		rb.resetImageTools();
	},

	enforceTextDragLimits: function() {
//		rb.log(" enforcing text drag limitations");
		var obj = rb.getCanvas().getActiveObject();
		var top = obj.top;
		var bottom = top + obj.height;
		var left = obj.left;
		var right = left + obj.width;

		var topBound = rb.textDragBox.top;
		var bottomBound = topBound + rb.textDragBox.height;
		var leftBound = rb.textDragBox.left;
		var rightBound = leftBound + rb.textDragBox.width;

		// capping logic here
		var left = Math.min(Math.max(left, leftBound), rightBound - rb.textDragBox.width);
		var top = Math.min(Math.max(top, topBound), bottomBound - rb.textDragBox.height);
		//	rb.log(" forcing drag left top " + left + " T " + top);
		obj.setLeft(left);
		obj.setTop(top);
	},

	reorderFrames: function(event, ui) {
		rb.log("reorderFrames: we have + reordered");

		rb.sendGaEvent('reorder_frames', "reorder_frames", 0);
		rb.frameHasChanges = true;
		rb.unsavedReorder = true;

		var neededFrameEntityId;
		var neededFrameIndexPosition = -1;
		var previousCurrentFrame = rb.getCurrentFrameIndex();

		jQuery('#frame-list-sort > li').each( function(idx, e) {

			neededFrameEntityId = jQuery(e).attr('data-frame-entity-id');
			if(neededFrameEntityId) {
				neededFrameIndexPosition = rb.getCurrentFrameDataPositionByEntityId(neededFrameEntityId);
			} else {
				rb.log("we could not find the needed entity for reordering")
			}

			var newFrameIndex = Number(idx+1);
			var previousFrameIndex = rb.frameData[neededFrameIndexPosition].frame_index;


			rb.frameData[neededFrameIndexPosition].frame_index = newFrameIndex;

			jQuery(e).find('.frame_identifier').html(FRAME_WORD + " " + newFrameIndex);
			jQuery(e).attr('data-frame-id', newFrameIndex);

		});

		if(rb.currentFrameIndex != 0) {
			rb.setCurrentFrameIndex(jQuery(".filmstrip-frame-active").attr('data-frame-id'));
		}

		jQuery(".frames").removeClass("frame-hover");


	},

	saveOnly: function() {
		rb.saveAndExitBit = false;
		rb.saveReel();

	},

	saveAndExit: function() {
		rb.showLoading();
		rb.saveAndExitBit = true;
		rb.saveReel();
	},

	approveReelDialog: function() {
		rb.generateConfirmDialog(jQuery(".approve-message").html(), 'rb.approveReel', false);
	},

	backgroundNoSortDialog: function() {
		jQuery('<div />').html(MSG_PROBLEM_SORT).dialog({
			autoOpen: true,
			modal: true,
			height: 'auto',
			resizable: false,
			buttons : {
				"Ok" : function() {
					jQuery(this).dialog("close");
				}
			}
		});
		jQuery(".ui-dialog-titlebar").hide();
	},

	generateConfirmDialog: function(msg, successFunction, cancelFunction) {
		jQuery('<div />').html(msg).dialog({
			autoOpen: true,
			modal: true,
			height: 'auto',
			resizable: false,
			buttons : {
				"Confirm" : function() {
					jQuery(this).dialog("close");
					rb.approveReel();
					//successFunction();
				},
				"Cancel" : function() {
					jQuery(this).dialog("close");
					if(cancelFunction !== false) {
						cancelFunction();
					}
				}
			}
		});
		jQuery(".ui-dialog-titlebar").hide();
	},

	deleteCurrentFrameDialog: function(ele) {
		jQuery('<div />').html(MSG_CONFIRM_DELETE_FRAME).dialog({
			autoOpen: true,
			modal: true,
			height: 'auto',
			resizable: false,
			buttons : {
				"Ok" : function() {
					jQuery(this).dialog("close");
					rb.deleteFrame(ele);
				},
				"Cancel" : function() {
					jQuery(this).dialog("close");
				}

			}
		});
		jQuery(".ui-dialog-titlebar").hide();
	},

	deleteFrame: function(ele) {
		rb.disableReorder(MSG_GENERIC);
		rb.log("deleteFrame:  removing frame data" );
		rb.resetFrameTools();
		var frameReference = jQuery(ele.target).attr('rel');
		var parentElement = jQuery('li[rel=' + frameReference + ']');
		var deleteFrameEntityId = parentElement.first().attr('data-frame-entity-id');
		var deleteFrameIndex = rb.getCurrentFrameDataPositionByEntityId(deleteFrameEntityId);
		rb.frameData[deleteFrameIndex].frame_data = null;
		rb.frameData[deleteFrameIndex].source_file = null;

		rb.sendGaEvent('delete_frame' + rb.getCurrentFrameIndex(), "delete_frame", 0);

		if(rb.getCurrentFrameIndex() == parentElement.first().attr('data-frame-id')) {
			rb.getCanvas().clear();
			rb.imageFrame = false;
			rb.textFrame = false;
			rb.frameHasChanges = true;
		}

		rb.clearThumbObjectBackground(parentElement.first());
		rb.saveReel();
	},

	continueChangeCurrentFrame: function(ele) {


		// TODO test element verify its element or attr to get elementr
		//var parentElement = jQuery('li[rel='+jQuery(ele.target).attr('rel')+']');
		var parentElement = jQuery(ele.target).closest('li');
		var msg = MSG_CHANGE_FRAME;
		rb.saveandChangeFrameBit = false;

		rb.getCanvas().clear();

		rb.resetFrameTools();

		rb.setCurrentFrameIndex(parentElement.attr('data-frame-id'));

		// we can technically handle 14 framees.
		if(rb.getCurrentFrameIndex() > FRAME_COUNT-1 || rb.getCurrentFrameIndex() < 0) {
			rb.log("continueChangeCurrentFrame:  forcing to frame one..");
			rb.setCurrentFrameIndex(1);
			msg = MSG_CHANGE_FRAME_FORCE;
		}


		rb.log("continueChangeCurrentFrame: changing to " + rb.getCurrentFrameIndex());

		rb.setActiveThumbClass(rb.getCurrentFrameIndex() == 0);

		rb.disableReorder(msg + String(rb.getCurrentFrameIndex()), CHANGE_FRAME_DELAY_TIME);

		rb.loadFrame();
	},

	changeCurrentFrame: function(ele) {
		if(rb.getCurrentFrameIndex() === 0) {
			// center is different...
			rb.log("changeCurrentFrame: center we are");

			var parentElement = jQuery(ele.target).closest('li');
			var clickedEntity = jQuery(parentElement).data('frame-entity-id');

			var frameReference = parentElement.attr('rel');
			//rb.beforeCenterFrameEntityId = rb.getCurrentFrameData().entity_id;
			//rb.beforeCenterFrameEntityId = clickedEntity;
			rb.saveandChangeFrameBit = ele;
			rb.doneEditCenterArtClick();
			return;
		}

		//See if the previous frame has changes
		rb.frameHasChanges = false;
		var lastCanvasHash = rb.hashCode(JSON.stringify(rb.getCanvas()));
		var lastCenterHash = rb.hashCode(JSON.stringify(rb.getCenterCanvas()));

		if(lastCanvasHash != rb.canvasHash && lastCenterHash != rb.canvasHash){
			rb.frameHasChanges = true;
		}

		rb.log("changeCurrentFrame:  we have a changeCurrentFrame " + rb.getCurrentFrameIndex() );
		if(rb.frameHasChanges == true && CUSTOMER_LOGGEDIN) {
			rb.saveandChangeFrameBit = ele;
			rb.saveReel();
		} else {
			rb.frameHasChanges = false;
			rb.continueChangeCurrentFrame(ele);
		}
	},

	updateFrameTextShadow: function(update) {
		for (var ti = 0; ti < rb.getCanvas()._objects.length; ti++) {
			if(rb.getCanvas()._objects[ti].type == "text") {
				rb.getCanvas()._objects[ti].shadow = false;
				if(update) {
					// phantom render issue - redefine shadow each render
					//rb.getCanvas()._objects[ti].shadow = new fabric.Shadow(PHANTOM_FABRIC_SHADOW_LARGE);
					rb.getTextShadowObject(rb.getCanvas()._objects[ti], true);

				}
			}
		}
	},

	updateFrameTextVisible: function(x) {
		for (var ti = 0; ti < rb.getCanvas()._objects.length; ti++) {
			if(rb.getCanvas()._objects[ti].type == "text") {
				rb.getCanvas()._objects[ti].visible = x;
			}
		}
	},

	justSendDownload: function(x) {
		var y = x.split(';base64,',2);
		document.location.href = 'data:application/octet-stream;charset=utf-16le;base64,' + y[1];
	},

	getTextPng: function(forceGeneration) {
		return this.getPng(true, forceGeneration == true);
	},

	getImagePng: function(forceGeneration) {
		return this.getPng(false, forceGeneration == true);
	},

	getPng: function(getTextLayer, forceGeneration) {
		forceGeneration = true;
		var isCenterArtRender = false; //rb.getCurrentFrameIndex() == 0;
		var isCenterArtMod = rb.getCurrentFrameIndex() == 0;
		rb.log(" in get PNG");
		// if we are not forced to and we have no changes. we could use the cached copies?

		rb.updateFrameTextShadow(true);


		if(!getTextLayer) {

			var preCacheImg = new Image();
			preCacheImg.onload = function() {
				if(preCacheImg && preCacheImg.src && rb.currentFrameImage) {
					//		rb.currentFrameImage.setElement(preCacheImg);
					//	rb.currentFrameImage.src = preCacheImg.src;
					rb.log(" in precache COMPLETE calling complete");
				}
			};

			rb.log(" in Precache");
			// this was precached in saveReel...
			var tmpSrc = rb.buildCurrentFrameImageUrl(false, false);
			rb.log(" in precache have img " + tmpSrc);

			preCacheImg.src = tmpSrc;
		}

		rb.getCanvas().deactivateAll();
		rb.log(" in finishGetPng ");

		var dimFactor = Number(CANVAS_DIM_MODIFIER);

		if(isCenterArtRender || isCenterArtMod) {
			dimFactor = Number(CENTER_CANVAS_DIM_MODIFIER);
		}

		var overlayObject =  jQuery.extend(true, {}, rb.getCanvas().overlayImage);

		rb.getCanvas().overlayImage = false;
		rb.getCanvas().backgroundColor = false;
		if(!isCenterArtRender) {
			rb.getActiveFrameCanvasImage().visible = false;
		}

		rb.renderCanvas();

		var textFrame = false;
		var imageFrame = false;
		// we use jpeg for the center as it doesnt need transparency and its 4X larger than the frames
		textFrame = rb.getCanvas().toDataURL({
			//format: isCenterArtRender ? 'jpeg' : 'png',
			format: !getTextLayer || isCenterArtRender ? 'jpeg' : 'png',
			//format: 'png',
			quality: 1,
			left: 0,
			top: 0,
			//	width: rb.getCanvas().getWidth(),
			//		height: rb.getCanvas().getHeight()
			multiplier: dimFactor
		});

		if(getTextLayer) {

			rb.restoreCanvasVisibility(overlayObject);
			return textFrame;
		}


		// hide the text; only get image.
		rb.getActiveFrameCanvasImage().visible = true;

		rb.updateFrameTextVisible(false);

		rb.renderCanvas();
		// TODO test saving the background as a jpeg to save on space.
		imageFrame = rb.getCanvas().toDataURL({
			format: isCenterArtMod ? 'jpeg' : 'png',
			quality: 1,
			left: 0,
			top: 0,
//				width: rb.getCanvas().getWidth(),
//				height: rb.getCanvas().getHeight(),
			multiplier: dimFactor
		});

		rb.restoreCanvasVisibility(overlayObject);

		var img=new Image();
		img.onload=function() {
			// replace the image with the low resolution one.
			if(img && img.src && rb.currentFrameImage) {
				//rb.currentFrameImage().setElement(img);
				//rb.currentFrameImage().src = img.src;
				rb.currentFrameImage.setElement(img);
				rb.currentFrameImage.src = img.src;
			}
		}
		img.src=rb.buildCurrentFrameImageUrl(false, true);

		return isCenterArtRender || (typeof getTextLayer != "undefined" && getTextLayer) ? textFrame : imageFrame;
	},

	restoreCanvasVisibility: function(overlayObject) {
		rb.getActiveFrameCanvasImage().visible = true;
		rb.getCanvas().overlayImage = overlayObject;
		rb.getCanvas().backgroundColor = 'black';
		rb.updateFrameTextVisible(true);
		rb.renderCanvas();
		//rb.getCanvas().calcOffset();
	},

	previewNextFrame: function() {
		rb.changePreviewFrame(rb.previewPosition + 1);
	},

	previewBackFrame: function() {
		rb.changePreviewFrame(rb.previewPosition - 1);
	},

	changePreviewFrame: function(current) {

		if(current < 1) {
			current = 7;
		}

		if(current > 7) {
			current = 1;
		}

		rb.previewPosition = current;
		var getDeg = (360/14) * ((rb.previewPosition - 1) * 2);
		jQuery('#active-reel-preview').css({transform: 'rotate('+getDeg+'deg)'}).css({WebkitTransform: 'rotate('+getDeg+'deg)'}).css({'-moz-transform': 'rotate('+getDeg+'deg)'});
		jQuery('#frame-preview').css('background-image', 'url(' + rb.buildCurrentFrameImageUrl(false, true, rb.frameData[rb.previewPosition].entity_id) + '&frame_preview=1' + rb.previewTime + ')').css('background-size', '100% auto');
		//jQuery('#frame-preview').css('background-image', 'url(' + rb.buildCurrentFrameImageUrl(false, true, rb.frameData[rb.previewPosition].entity_id) + ')').css('background-size', '100% auto');
		jQuery('.header-frame > span').html(rb.previewPosition);
	},

	showPreview: function() {
		if(rb.currentFrameIndex == 0){
			jQuery('div.preview-open-centeredit').dialog(
				{ 
					modal : true,
					left: '50%', 
					top: '18%', 
					'margin-left': '-350px',
					buttons : {
						"OK" : function() {
							jQuery(this).dialog("close");
						}
					}
				}
			);
			jQuery(".ui-dialog-titlebar").hide();
			return false;
		}
		// all frames need a source, text and background except ! 0
		//rb.frameData[0].source_file

		var canPreview = true;
		rb.previewPosition = 0;
		for (var i = 0; i < FRAME_COUNT; i++) {
			try {
				var frameData = rb.frameData[i];
				//if (frameData.source_file && frameData.text_file && (i == 0 || frameData.background_file)) {
				if (frameData.frame_data.canvas_json && frameData.frame_data.canvas_json.length) {
					continue;
				} else {
					rb.log("frame issue with " + i );
					canPreview = false;
					break;
				}
			} catch (Err) {
				canPreview = false;
				rb.log(Err, true);
			}
		}

		if(!canPreview) {
			jQuery('div.preview-unfinished-reel').dialog({
					buttons : {
						"OK" : function() {
							jQuery(this).dialog("close");
						}
					}
				}
			);
			jQuery(".ui-dialog-titlebar").hide();
			return false;
		}

		//See if the frame has changes
		rb.frameHasChanges = false;
                var lastCanvasHash = rb.hashCode(JSON.stringify(rb.getCanvas()));

                if(lastCanvasHash != rb.canvasHash || rb.unsavedReorder == true){
                        rb.frameHasChanges = true;
                }

		if(rb.frameHasChanges == true) {
			rb.saveandContinuePreview = true;
			rb.saveReel();
		} else {
			rb.processPreviewReel();
		}

	},

	updateLoadingMessage: function(message) {
		jQuery('#loading-message').html('<h1>' + message + '</h1>');
		if(message == '') {
			jQuery('#loading-message').hide();
		} else {
			jQuery('#loading-message').show();
		}
	},

	processPreviewReel: function() {
		rb.showLoading();
		var xData = {};
		xData.reel_id = rb.reel_id;
		xData.action = 'generate_reel';
		rb.previewGenerationUpdater = setInterval(function() {
			var xStatusData = {};
			xStatusData.reel_id = rb.reel_id;
			xStatusData.action = 'reel_status';
			jQuery.ajax({
				type: "POST",
				url: rb.postUrl,
				data: xStatusData,
				dataType: 'json',
				complete: function(xretData, jqXHR) {
					//retData = jQuery.parseJSON(retData);
					rb.log("we have data " );
					rb.log(xretData);
					if(xretData.responseJSON.success) {
						rb.log("message!" );
						rb.log(xretData.responseJSON);
						rb.updateLoadingMessage(xretData.responseJSON.message);
					}
				}
			});
		}, REEL_GENERATION_STATUS_UPDATE);


		jQuery.ajax({
			type: "POST",
			url: rb.postUrl,
			data: xData,
			dataType: 'json',
			complete: function(retData, jqXHR) {
				//retData = jQuery.parseJSON(retData);
				rb.updateLoadingMessage(MSG_GENERATION_COMPLETE);
				clearInterval(rb.previewGenerationUpdater);
				rb.log(" generate_reel we have success for process preview");
				rb.log(retData);
				rb._recent_json = retData;
				rb.forceLoginRedirect(retData);
				// save the source we will need it.

				if(!retData.status || !retData.responseJSON.success) {
					rb.log("we have an error " + retData.responseJSON.message, true);
					rb.hideLoading();
					jQuery('<div>' + MSG_PROBLEM_PREVIEW + '(' + retData.responseJSON.message + ')' + '</div>').dialog(
						{
							buttons : {
								"Ok" : function() {
									jQuery(this).dialog("close");
								}
							}
						}
					);
					return;
				}

				rb.sendGaEvent('generate_reel', "save_reel", 0);

				var ImgSrc = BASE_URL + "reelbuilderCb/?i3d_image=reel&reel_id=" + rb.reel_id + "&thumb=false&jpeg=true&sf_hash=" + rb.hashCode(JSON.stringify(rb.frameData));
				var imgObj = new Image();
				rb.previewTime =  new Date().getTime();
				imgObj.onload = function () {
					jQuery('#active-reel-preview').attr('src', imgObj.src);

					rb.changePreviewFrame(1);
					jQuery('#edit-tools').hide();
					jQuery('#edit-frame').hide();
					jQuery('#container-help-buttons').hide();
					jQuery('.builder-footer-container').hide();
					jQuery('.reorder-strip-container').hide();
					jQuery('#center-art-canvas').hide();
					jQuery('#preview-page-container').show();
					rb.hideLoading();
				};
				imgObj.src = ImgSrc;
			}
		});
	},

	approveReel: function() {

		rb.showLoading();

		rb.log("woot complete reel.");
		rb.sendGaEvent('approve_reel_attempt', "save_reel", 0);

		var xData = {};
		xData.reel_id = rb.reel_id;
		xData.action = 'complete_reel';

		jQuery.ajax({
			type: "POST",
			url: rb.postUrl,
			data: xData,
			dataType: 'json',
			complete: function(retData, jqXHR) {
				//retData = jQuery.parseJSON(retData);
				rb.log("we have success complete_reel ");
				rb.log(retData);
				rb._recent_json = retData;
				rb.updateUrlReelId();
				rb.forceLoginRedirect(retData);
				// save the source we will need it.

				if(!retData.success) {
					rb.log("we have an error " + retData.message, true);
					jQuery('<div>' + MSG_PROBLEM_IMAGE + '</div>').dialog(
						{
							buttons : {
								"Ok" : function() {
									jQuery(this).dialog("close");
									if(rb.getUrlParameter('reel_id')) {
										document.location.reload();
									} else {
										document.location.href = BASE_URL + 'customer/account';
									}
								}
							}
						}
					);

					return;
				}
				//rb.hideLoading();
				rb.sendGaEvent('approve_reel', "save_reel", 1);

				document.location.href =  BASE_URL + 'customer/account';

			}
		});
	},

	cancelPreviewEditReel: function() {
		rb.log(" cancelPreviewEditReel not written ");
		rb.sendGaEvent('approve_reel_cancel', "save_reel", 0);

		rb.showLoading();
		jQuery('#edit-tools').show();
		jQuery('#edit-frame').show();
		jQuery('#preview-page-container').hide();
		jQuery('.builder-footer-container').show();
		jQuery('.reorder-strip-container').show();
		jQuery('#container-help-buttons').show();
		rb.hideLoading();
	},

	removeActiveText: function() {
		if(rb.getCanvas().getActiveObject() == null || rb.getCanvas().getActiveObject().type != "text") {
			return;
		}
		rb.getCanvas().getActiveObject().remove();
		rb.getCanvas().deactivateAll();
		rb.resetTextTools();
		rb.frameHasChanges = true;

	},

	isActiveObjectText: function() {
		return rb.getCanvas().getActiveObject() != null && rb.getCanvas().getActiveObject().type == "text";
	},

	updateActiveTextOptions: function() {


		rb.getCanvas().getActiveObject().shadow = false;
		rb.getCanvas().getActiveObject().fontFamily = jQuery("#cmb-font > option:selected").text() ||  DEFAULT_FONT;
		rb.getCanvas().getActiveObject().fill = jQuery("input:radio[name=color-choice]:checked").val();
		rb.getCanvas().getActiveObject().text = jQuery("#txt-reelText").val();
		rb.getCanvas().getActiveObject().fontSize = String(jQuery("input:radio[name=font-size]:checked").val() || 30);

		if(rb.getCanvas().getActiveObject().fontFamily == 'Kunstler Script' || rb.getCanvas().getActiveObject().fontFamily == 'Freestyle Script') {
			rb.getCanvas().getActiveObject().fontSize = jQuery("input:radio[name=font-size]:checked").val() * 2;
		}

		rb.getTextShadowObject(rb.getCanvas().getActiveObject());
		rb.log(" updateActiveTextOptions: updated  ")
	},

	// TODO one more case for fancy sccript..
	getTextShadowObject: function(textObject, isPhantom) {
		var shadow = false;
		if(textObject.fontSize <= '22') {
			if(textObject.fill <= '#000000') {
				shadow = 	isPhantom ? PHANTOM_FABRIC_SHADOW_SMALL + " " + PHANTOM_FABRIC_SHADOW_LIGHT : FABRIC_SHADOW_SMALL + " " + FABRIC_SHADOW_LIGHT;
			} else {
				shadow = 	isPhantom ? PHANTOM_FABRIC_SHADOW_SMALL + " " + PHANTOM_FABRIC_SHADOW_DARK : FABRIC_SHADOW_SMALL + " " + FABRIC_SHADOW_DARK;
			}
		} else {
			if(textObject.fill <= '#000000') {
				shadow = 	isPhantom ? PHANTOM_FABRIC_SHADOW_LARGE + PHANTOM_FABRIC_SHADOW_LIGHT : FABRIC_SHADOW_LARGE + " " + FABRIC_SHADOW_LIGHT;
			} else {
				shadow = 	isPhantom ? PHANTOM_FABRIC_SHADOW_LARGE + " " + PHANTOM_FABRIC_SHADOW_DARK : FABRIC_SHADOW_LARGE + " " + FABRIC_SHADOW_DARK;
			}
		}

		textObject.shadow = new fabric.Shadow(shadow);
	},

	addTextToActiveFrame: function() {
		rb.log("add active text");

		var frameText = new fabric.Text(String(jQuery("#txt-reelText").val()), {
			fontWeight:"bold",
			left: rb.getCanvas().getWidth()/2,
			top: rb.getCanvas().getHeight()/2,
			fill: 'white'
			//	shadow: new fabric.Shadow(FABRIC_SHADOW_LARGE)
			//shadow: FABRIC_SHADOW_LARGE
		});

		rb.getTextShadowObject(frameText, false);

		rb.getCanvas().add(frameText);
		rb.getCanvas().setActiveObject(frameText);
		rb.updateActiveTextOptions();
		rb.frameHasChanges = true;

		rb.renderCanvas();

		jQuery('#txt-reelText').focus();
	},

	updateTextChange: function() {
		if(rb.isActiveObjectText()) {
			rb.getCanvas().getActiveObject().text = jQuery("#txt-reelText").val();
			rb.renderCanvas();
		}
	},

	forceUpdateFontDdDisplay: function(selectionValue, forceUpdate) {
		selectionValue = typeof selectionValue == "undefined" ? DEFAULT_FONT : selectionValue;
		forceUpdate = typeof forceUpdate == "undefined" ? false : forceUpdate;

		if(forceUpdate || (selectionValue && selectionValue != jQuery("#cmb-font").val())) {
			jQuery("#cmb-font").val(selectionValue);
			jQuery( "#cmb-font" ).selectmenu( "refresh" );
			jQuery('div.ui-selectmenu-menu').find('li').each(function(i, e) { jQuery(e).css("font-family", jQuery(e).text()); });
		}

	},

	updateTextOptionsChange: function() {
		jQuery('#cmb-font-button > .ui-selectmenu-text').css("font-family", jQuery('#cmb-font-button > .ui-selectmenu-text').text());
		if(rb.skipTextUpdate == true) {
			rb.log("updateTextOptionsChange: skip update");
			return;
		}

		if(rb.isActiveObjectText()) {
			rb.log("updateTextOptionsChange: running updates");
			rb.updateActiveTextOptions();
			rb.renderCanvas();
		}
	}

});


stockArtClass = function() {};

jQuery.extend(stockArtClass.prototype,{
	tree : new Array(),
	currentLevel : false,
	previousLevel : false,
	indexedTree : {},
	activeName : 'Stock Art',

	getCurrentLevel: function() {
		return this.currentLevel;
	},

	removeDialog: function() {
		try {
			jQuery('#stock-art-div').hide();
			jQuery('.ui-dialog-content').dialog('close');

		} catch (Err) {
			// it was closed?
		}
	},

	reset: function() {
		this.currentLevel = stockArt.tree.children;
	},

	showDialog: function(index) {
		jQuery('#rb-loading').children().hide();
		if(typeof index == "undefined") {
			index = false;
		}
		if(!this.currentLevel || (index == -1 && !stockArt.previousLevel)) {
			this.reset();
		}


		if(this.indexedTree.hasOwnProperty(index)) {
			this.activeName = index;

			if(!this.currentLevel) {
				stockArt.previousLevel = this.indexedTree[index];
			} else {
				stockArt.previousLevel = this.currentLevel;
			}

			this.currentLevel = this.indexedTree[index];
		}

		if(index == -1) {
			if(!stockArt.previousLevel || stockArt.currentLevel.path.split("/").length == 3) {
				this.reset();
			} else {
				this.currentLevel = stockArt.previousLevel;
			}
		}

		for(var propertyName in stockArt.currentLevel) {
			if(!(propertyName == 'is_dir' || propertyName == 'thumb' || propertyName == 'path' || propertyName == 'children')) {
				//rb.log("what gives " + propertyName);
				stockArt.indexedTree[propertyName] = stockArt.currentLevel[propertyName];
			}
		}

		for(var propertyName in stockArt.currentLevel.children) {
			if(!(propertyName == 'is_dir' || propertyName == 'thumb' || propertyName == 'path' || propertyName == 'children')) {
				//	rb.log("what gives " + propertyName);
				stockArt.indexedTree[propertyName] = stockArt.currentLevel.children[propertyName];
				//	stockArt.indexedTree[propertyName].parent = stockArt.currentLevel;
			}
		}

		var source   = jQuery("#stock-art-template").html();
		var template = Handlebars.compile(source);
		var isCurrDir = false;
		try {
			isCurrDir = stockArt.currentLevel.children[Object.keys(stockArt.currentLevel.children)[0]].is_dir != undefined &&
			stockArt.currentLevel.children[Object.keys(stockArt.currentLevel.children)[0]].is_dir;
		} catch (Err) {
			isCurrDir = false;
		}
		try {
			if(!isCurrDir && stockArt.currentLevel[Object.keys(stockArt.currentLevel)[0]].is_dir != undefined) {
				isCurrDir = stockArt.currentLevel[Object.keys(stockArt.currentLevel)[0]].is_dir;
			}
		} catch (Err) {
		}

		var context  = {listItems: stockArt.currentLevel, currIsDir: isCurrDir, currentName: stockArt.activeName};
		//var html     = template(context);
		template(context);
		this.removeDialog();
		jQuery(template(context)).insertAfter('#stock-art-template');
		jQuery('#stock-art-div').clone().dialog({
			width: '700', 
			height: 'auto', 
			resizable: false, 
			modal: true,
			buttons : {
				"Cancel" : function() {
					stockArt.removeDialog();
				}
			},
			left: '50%', 
			top: '18%', 
			'margin-left': '-350px'
		});


		jQuery(".ui-dialog-titlebar").hide();

	}
});

// allow us to splice arrays easy
Array.prototype.move = function (old_index, new_index) {
	while (old_index < 0) {
		old_index += this.length;
	}
	while (new_index < 0) {
		new_index += this.length;
	}
	if (new_index >= this.length) {
		var k = new_index - this.length;
		while ((k--) + 1) {
			this.push(undefined);
		}
	}
	this.splice(new_index, 0, this.splice(old_index, 1)[0]);
	return this;
};

Handlebars.registerHelper('ifIsDir', function(v1, options) {
	return v1.is_dir == true;
});

Handlebars.registerHelper('ifIsNotDir', function(v1, options) {
	return v1.is_dir !== true;
});


jQuery(document).ready(function()
{

	//Remove the frame-hover edit for any click on the document.
	jQuery(document).bind("click tap", function() {
		jQuery(".frames").removeClass("frame-hover");
	});

	rb = new ReelBuilder();

	rb.debugModeEnabled();


	rb.showLoading();
	rb.canvas = new fabric.Canvas('reelBuilderCanvas');
	rb.centerCanvas = new fabric.Canvas('centerReelBuilderCanvas');
	rb.setupCanvasBits();
	rb.setupCenterCanvasBits();



	// lets let this goto 400
	jQuery( "#slider-scale" ).slider({
		min:MIN_SCALE,
		max:MAX_SCALE,
		value: SCALE_DEFAULT * SCALE_MODIFIER,
		slide: function (event, ui) {
			rb.setActiveFrameImageScale(event, ui);
		},
		change:function(event, ui) {
			rb.setActiveFrameImageScale(event, ui);
		}
	});
	jQuery( "#slider-rotate" ).slider({
		min:MIN_ANGLE,
		max:MAX_ANGLE,
		value: ROTATE_DEFAULT,
		slide: function (event, ui) {
			rb.setActiveFrameImageRotate(event, ui);
		},
		change:function(event, ui){
			rb.setActiveFrameImageRotate(event, ui)
		}
	});

	jQuery( "#slider-brightness" ).slider({
		min:-255,
		max:255,
		value: BRIGHTNESS_DEFAULT,
		// it is too intensive to do as you slide -SH
		slide: function (event, ui) {
			//rb.setActiveFrameImageBrightness(event, ui);
		},
		change:function(event, ui){
			rb.setActiveFrameImageBrightness(event, ui)
		}
	});
	jQuery( "#slider-contrast" ).slider({
		min:-255,
		max:255,
		value: CONTRAST_DEFAULT,
		// it is too intensive to do as you slide SH
		slide: function (event, ui) {
			//rb.setActiveFrameImageContrast(event, ui);
		},
		change:function(event, ui){
			rb.setActiveFrameImageContrast(event, ui)
		}
	});


	jQuery('#preview-reel-link').click(function() { rb.showPreview(); } );

	jQuery( "#rad-sepia, #rad-bw, #rad-fullColor " ).click(function(e) { rb.applyImageColorFilter(e); });

	jQuery('#txt-reelName').change(function() { jQuery('#txt-reelName').attr('title', jQuery('#txt-reelName').val());});
	jQuery('#txt-reelText').change(function() { jQuery('#txt-reelText').attr('title', jQuery('#txt-reelText').val());});

	//Add hover frame class
	/*jQuery(".frames").hover(function(){
	 jQuery(this).addClass('frame-hover');
	 }, function(){
	 jQuery(this).removeClass('frame-hover');
	 });*/

	jQuery( "#font-size-options" ).buttonset().change( function() { rb.updateTextOptionsChange()  } );
	jQuery( "#font-color-options" ).buttonset().change( function() { rb.updateTextOptionsChange()  } );

	jQuery( "#txt-reelText").bind("input",function(e) {
//		rb.log(" text event " + e.type );
		if(rb.isActiveObjectText()) {
			rb.updateTextChange(true);
			//	rb.log("text input box update active text");
		} else if(jQuery( "#txt-reelText").val() != '') {
			rb.addTextToActiveFrame();
			//	rb.log("text input box  NOT ACTIVE text");
		}

	});

	jQuery( "#color-options" ).buttonset();

	jQuery( "#cmb-font" ).selectmenu({ width: 190, change: function( event, ui ) { rb.updateTextOptionsChange() } }).selectmenu( "menuWidget" ).css('height', '170px');
	jQuery( "#cmb-font" ).selectmenu( "refresh" );

	rb.forceUpdateFontDdDisplay(false, true);


	jQuery('#btn-remove-text').click(function() { rb.removeActiveText(); });
	jQuery('#center_active_image').click(function() { rb.centerActiveImage(); });

	jQuery('#img_popup').click(function() {
		jQuery('#container-img-buttons').clone().dialog({
			autoOpen: true,
			modal: true,
			height: 'auto',
			resizable: false,
			buttons : {
				"Cancel" : function() {
					jQuery(this).dialog("close");
				}
			}
		});
		jQuery(".ui-dialog-titlebar").hide();
	});

	jQuery('#done-center-art').click(function() { rb.doneEditCenterArtClick(); });

	rb.resetFrameTools();

	jQuery( "#frame-list-sort" ).sortable({
		delay: 150,
		deactivate: function(event, ui) {
			rb.reorderFrames(event, ui);
		}
	});


	jQuery("#frame-list-sort").on("click", "li", function(ele) {
		rb.log("li eleemnt click");
		rb.changeCurrentFrame(ele);
	});

	rb.setupCssZoomForSmallScreens();
	// deprecated
	// //rb.setupFrameDragOrDeviceClick();


	// if we are not a phantom and we do not have a realistic browser.
	if(!rb.getUrlParameter('frame_id') && rb.needsBrowserUpgrade()) {
		rb.log(" browser does not support file reader this is an issue.")
		rb.notifyBrowserUpgrade();
	} else {
		rb.log("queye load reel from ready ");
		rb.queueLoadReel();
	}

	stockArt = new stockArtClass();
	stockArt.tree = _stockArtTree;
});
